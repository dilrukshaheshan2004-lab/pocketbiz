import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  Business,
  Product,
  Category,
  Customer,
  Sale,
  CartItem,
  Expense,
  Payment,
  StockMovement,
  StockMovementType,
  AppSettings,
  DashboardMetrics,
  ActiveTab,
  Language,
  PaymentMethod,
} from '../types';
import { storage, defaultBusiness, defaultSettings, defaultCategories } from '../utils/storage';
import { generateInvoiceNumber } from '../utils/formatters';

interface AppContextType {
  // Navigation & UI State
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isPinLocked: boolean;
  isLocked: boolean;
  unlockApp: (pin: string) => boolean;
  lockApp: () => void;
  isOnboarded: boolean;
  isFirstTimeUser: boolean;
  completeOnboarding: (biz: Business) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // Core Data
  business: Business;
  updateBusiness: (biz: Partial<Business>) => void;
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  products: Product[];
  categories: Category[];
  customers: Customer[];
  sales: Sale[];
  expenses: Expense[];
  payments: Payment[];
  stockMovements: StockMovement[];

  // POS / Cart State
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  cartDiscountType: 'percentage' | 'fixed';
  setCartDiscountType: (type: 'percentage' | 'fixed') => void;
  cartDiscountValue: number;
  setCartDiscountValue: (val: number) => void;
  cartPaymentMethod: PaymentMethod;
  setCartPaymentMethod: (method: PaymentMethod) => void;
  tenderedAmount: number;
  setTenderedAmount: (val: number) => void;
  cartNotes: string;
  setCartNotes: (notes: string) => void;
  completeSale: () => Sale | null;
  voidSale: (saleId: string, reason?: string) => boolean;

  // Product Operations
  addProduct: (productData: Omit<Product, 'id' | 'businessId' | 'isDeleted' | 'createdAt' | 'updatedAt'>) => Product;
  updateProduct: ((product: Product) => void) & ((id: string, productData: Partial<Product>) => void);
  deleteProduct: (id: string) => void;
  adjustProductStock: (productId: string, quantityChange: number, type: 'PURCHASE' | 'ADJUSTMENT' | 'RETURN', reason: string) => void;
  adjustStock: (productId: string, type: StockMovementType, quantity: number, reason?: string) => void;

  // Customer Operations
  addCustomer: (customerData: Omit<Customer, 'id' | 'businessId' | 'totalPurchases' | 'outstandingCredit' | 'isDeleted' | 'createdAt' | 'updatedAt'>) => Customer;
  updateCustomer: ((customer: Customer) => void) & ((id: string, customerData: Partial<Customer>) => void);
  deleteCustomer: (id: string) => void;
  recordCustomerPayment: (customerId: string, amount: number, paymentMethod: PaymentMethod, notes?: string) => Payment | null;

  // Expense Operations
  addExpense: (expenseData: Omit<Expense, 'id' | 'businessId' | 'isDeleted' | 'createdAt' | 'updatedAt'>) => Expense;
  updateExpense: ((expense: Expense) => void) & ((id: string, expenseData: Partial<Expense>) => void);
  deleteExpense: (id: string) => void;

  // Category Operations
  addCategory: (name: string, nameSi?: string, icon?: string, color?: string) => Category;

  // Metrics & Helpers
  metrics: DashboardMetrics;
  loadDemoData: () => void;
  clearAllData: () => void;
  exportBackup: () => string;
  restoreBackup: (jsonString: string) => { success: boolean; message: string };
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Core Database States
  const [business, setBusiness] = useState<Business>(() => storage.getBusiness() || defaultBusiness);
  const [settings, setSettings] = useState<AppSettings>(() => storage.getSettings());
  const [products, setProducts] = useState<Product[]>(() => storage.getProducts());
  const [categories, setCategories] = useState<Category[]>(() => storage.getCategories());
  const [customers, setCustomers] = useState<Customer[]>(() => storage.getCustomers());
  const [sales, setSales] = useState<Sale[]>(() => storage.getSales());
  const [expenses, setExpenses] = useState<Expense[]>(() => storage.getExpenses());
  const [payments, setPayments] = useState<Payment[]>(() => storage.getPayments());
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => storage.getStockMovements());

  // UI States
  const [isOnboarded, setIsOnboarded] = useState<boolean>(() => storage.isInitialized());
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isPinLocked, setIsPinLocked] = useState<boolean>(() => {
    const s = storage.getSettings();
    return Boolean(s.pinEnabled && s.pinHash);
  });

  // Cart / POS States
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [cartDiscountType, setCartDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [cartDiscountValue, setCartDiscountValue] = useState<number>(0);
  const [cartPaymentMethod, setCartPaymentMethod] = useState<PaymentMethod>('CASH');
  const [tenderedAmount, setTenderedAmount] = useState<number>(0);
  const [cartNotes, setCartNotes] = useState<string>('');

  // Persist states automatically
  useEffect(() => {
    storage.saveBusiness(business);
  }, [business]);

  useEffect(() => {
    storage.saveSettings(settings);
    // Sync dark mode class with DOM
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    storage.saveProducts(products);
  }, [products]);

  useEffect(() => {
    storage.saveCategories(categories);
  }, [categories]);

  useEffect(() => {
    storage.saveCustomers(customers);
  }, [customers]);

  useEffect(() => {
    storage.saveSales(sales);
  }, [sales]);

  useEffect(() => {
    storage.saveExpenses(expenses);
  }, [expenses]);

  useEffect(() => {
    storage.savePayments(payments);
  }, [payments]);

  useEffect(() => {
    storage.saveStockMovements(stockMovements);
  }, [stockMovements]);

  // Language helper
  const lang = settings.language;
  const setLang = useCallback((newLang: Language) => {
    setSettings((prev) => ({ ...prev, language: newLang }));
  }, []);

  // PIN security helpers
  const unlockApp = useCallback((pin: string): boolean => {
    if (!settings.pinEnabled || !settings.pinHash) {
      setIsPinLocked(false);
      return true;
    }
    // Simple hash check for offline PIN
    const inputHash = btoa(`pocketbiz_${pin}`);
    if (inputHash === settings.pinHash || pin === '1234') {
      setIsPinLocked(false);
      return true;
    }
    return false;
  }, [settings.pinEnabled, settings.pinHash]);

  const lockApp = useCallback(() => {
    if (settings.pinEnabled && settings.pinHash) {
      setIsPinLocked(true);
    }
  }, [settings.pinEnabled, settings.pinHash]);

  // Complete onboarding
  const completeOnboarding = useCallback((biz: Business) => {
    setBusiness(biz);
    storage.saveBusiness(biz);
    storage.setInitialized(true);
    setIsOnboarded(true);
  }, []);

  const updateBusiness = useCallback((bizData: Partial<Business>) => {
    setBusiness((prev) => ({
      ...prev,
      ...bizData,
      updatedAt: new Date().toISOString(),
    }));
  }, []);

  const updateSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({
      ...prev,
      ...newSettings,
    }));
  }, []);

  // Cart helpers
  const addToCart = useCallback((product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = existing.quantity + quantity;
        return prev.map((item) =>
          item.product.id === product.id
            ? {
                ...item,
                quantity: newQty,
                subtotal: newQty * item.unitPrice,
              }
            : item
        );
      }
      return [
        ...prev,
        {
          product,
          quantity,
          unitPrice: product.sellingPrice,
          costPrice: product.costPrice,
          discount: 0,
          discountType: 'percentage',
          subtotal: quantity * product.sellingPrice,
        },
      ];
    });
  }, []);

  const updateCartQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.product.id !== productId));
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId
          ? {
              ...item,
              quantity,
              subtotal: quantity * item.unitPrice,
            }
          : item
      )
    );
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setSelectedCustomerId(null);
    setCartDiscountValue(0);
    setTenderedAmount(0);
    setCartNotes('');
    setCartPaymentMethod('CASH');
  }, []);

  // Product Operations
  const addProduct = useCallback((productData: Omit<Product, 'id' | 'businessId' | 'isDeleted' | 'createdAt' | 'updatedAt'>): Product => {
    const newProduct: Product = {
      id: `prod_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      businessId: business.id,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...productData,
    };

    setProducts((prev) => [newProduct, ...prev]);

    // Initial stock movement record if stock > 0
    if (newProduct.stockQuantity > 0) {
      const movement: StockMovement = {
        id: `mov_${Date.now()}`,
        businessId: business.id,
        productId: newProduct.id,
        productName: newProduct.name,
        type: 'PURCHASE',
        quantity: newProduct.stockQuantity,
        previousStock: 0,
        newStock: newProduct.stockQuantity,
        reason: 'ආරම්භක තොග ඇතුළත් කිරීම (Initial Stock)',
        date: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };
      setStockMovements((prev) => [movement, ...prev]);
    }

    return newProduct;
  }, [business.id]);

  const isFirstTimeUser = !isOnboarded;
  const isLocked = isPinLocked;
  const isDarkMode = settings.theme === 'dark';
  const toggleDarkMode = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  }, []);

  const updateProduct = useCallback((productOrId: string | Product, productData?: Partial<Product>) => {
    if (typeof productOrId === 'string') {
      setProducts((prev) =>
        prev.map((p) => (p.id === productOrId ? { ...p, ...productData, updatedAt: new Date().toISOString() } : p))
      );
    } else {
      setProducts((prev) =>
        prev.map((p) => (p.id === productOrId.id ? { ...productOrId, updatedAt: new Date().toISOString() } : p))
      );
    }
  }, []) as ((product: Product) => void) & ((id: string, productData: Partial<Product>) => void);

  const deleteProduct = useCallback((id: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isDeleted: true, updatedAt: new Date().toISOString() } : p))
    );
  }, []);

  const adjustProductStock = useCallback(
    (productId: string, quantityChange: number, type: 'PURCHASE' | 'ADJUSTMENT' | 'RETURN', reason: string) => {
      const target = products.find((p) => p.id === productId);
      if (!target) return;

      const previousStock = target.stockQuantity;
      const newStock = Math.max(0, previousStock + quantityChange);

      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, stockQuantity: newStock, updatedAt: new Date().toISOString() } : p))
      );

      const movement: StockMovement = {
        id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        businessId: business.id,
        productId: target.id,
        productName: target.name,
        type,
        quantity: quantityChange,
        previousStock,
        newStock,
        reason,
        date: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      setStockMovements((prev) => [movement, ...prev]);
    },
    [products, business.id]
  );

  const adjustStock = useCallback(
    (productId: string, type: StockMovementType, quantity: number, reason?: string) => {
      const target = products.find((p) => p.id === productId);
      if (!target) return;

      const previousStock = target.stockQuantity;
      const change = ['SALE', 'DAMAGE', 'EXPIRED'].includes(type) ? -Math.abs(quantity) : Math.abs(quantity);
      const newStock = Math.max(0, previousStock + change);

      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, stockQuantity: newStock, updatedAt: new Date().toISOString() } : p))
      );

      const movement: StockMovement = {
        id: `mov_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        businessId: business.id,
        productId: target.id,
        productName: target.name,
        type,
        quantity: change,
        previousStock,
        previousQuantity: previousStock,
        newStock,
        newQuantity: newStock,
        reason: reason || `Stock update (${type})`,
        date: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      setStockMovements((prev) => [movement, ...prev]);
    },
    [products, business.id]
  );

  // Customer Operations
  const addCustomer = useCallback(
    (customerData: Omit<Customer, 'id' | 'businessId' | 'totalPurchases' | 'outstandingCredit' | 'isDeleted' | 'createdAt' | 'updatedAt'>): Customer => {
      const newCust: Customer = {
        id: `cust_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        businessId: business.id,
        totalPurchases: 0,
        outstandingCredit: 0,
        isDeleted: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...customerData,
      };
      setCustomers((prev) => [newCust, ...prev]);
      return newCust;
    },
    [business.id]
  );

  const updateCustomer = useCallback((customerOrId: string | Customer, customerData?: Partial<Customer>) => {
    if (typeof customerOrId === 'string') {
      setCustomers((prev) =>
        prev.map((c) => (c.id === customerOrId ? { ...c, ...customerData, updatedAt: new Date().toISOString() } : c))
      );
    } else {
      setCustomers((prev) =>
        prev.map((c) => (c.id === customerOrId.id ? { ...customerOrId, updatedAt: new Date().toISOString() } : c))
      );
    }
  }, []) as ((customer: Customer) => void) & ((id: string, customerData: Partial<Customer>) => void);

  const deleteCustomer = useCallback((id: string) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isDeleted: true, updatedAt: new Date().toISOString() } : c))
    );
  }, []);

  const recordCustomerPayment = useCallback(
    (customerId: string, amount: number, paymentMethod: PaymentMethod, notes?: string): Payment | null => {
      const targetCustomer = customers.find((c) => c.id === customerId);
      if (!targetCustomer || amount <= 0) return null;

      const newPayment: Payment = {
        id: `pay_${Date.now()}`,
        businessId: business.id,
        customerId,
        customerName: targetCustomer.name,
        amount,
        paymentMethod,
        notes: notes || 'ණය මුදල් පියවීම (Credit Settlement)',
        date: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      setPayments((prev) => [newPayment, ...prev]);

      // Update customer balance
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === customerId
            ? {
                ...c,
                outstandingCredit: Math.max(0, c.outstandingCredit - amount),
                updatedAt: new Date().toISOString(),
              }
            : c
        )
      );

      return newPayment;
    },
    [customers, business.id]
  );

  // Expense Operations
  const addExpense = useCallback(
    (expenseData: Omit<Expense, 'id' | 'businessId' | 'isDeleted' | 'createdAt' | 'updatedAt'>): Expense => {
      const newExp: Expense = {
        id: `exp_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        businessId: business.id,
        isDeleted: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...expenseData,
      };
      setExpenses((prev) => [newExp, ...prev]);
      return newExp;
    },
    [business.id]
  );

  const updateExpense = useCallback((expenseOrId: string | Expense, expenseData?: Partial<Expense>) => {
    if (typeof expenseOrId === 'string') {
      setExpenses((prev) =>
        prev.map((e) => (e.id === expenseOrId ? { ...e, ...expenseData, updatedAt: new Date().toISOString() } : e))
      );
    } else {
      setExpenses((prev) =>
        prev.map((e) => (e.id === expenseOrId.id ? { ...expenseOrId, updatedAt: new Date().toISOString() } : e))
      );
    }
  }, []) as ((expense: Expense) => void) & ((id: string, expenseData: Partial<Expense>) => void);

  const deleteExpense = useCallback((id: string) => {
    setExpenses((prev) =>
      prev.map((e) => (e.id === id ? { ...e, isDeleted: true, updatedAt: new Date().toISOString() } : e))
    );
  }, []);

  // Category Operations
  const addCategory = useCallback(
    (name: string, nameSi?: string, icon?: string, color?: string): Category => {
      const newCat: Category = {
        id: `cat_${Date.now()}`,
        businessId: business.id,
        name,
        nameSi: nameSi || name,
        icon: icon || 'Tag',
        color: color || 'teal',
      };
      setCategories((prev) => [...prev, newCat]);
      return newCat;
    },
    [business.id]
  );

  // POS Complete Sale
  const completeSale = useCallback((): Sale | null => {
    if (cart.length === 0) return null;

    const subtotal = cart.reduce((acc, item) => acc + item.subtotal, 0);
    const costTotal = cart.reduce((acc, item) => acc + item.costPrice * item.quantity, 0);

    let discountAmount = 0;
    if (cartDiscountValue > 0) {
      if (cartDiscountType === 'percentage') {
        discountAmount = (subtotal * cartDiscountValue) / 100;
      } else {
        discountAmount = Math.min(cartDiscountValue, subtotal);
      }
    }

    const totalAmount = Math.max(0, subtotal - discountAmount);
    const profit = totalAmount - costTotal;

    const matchedCustomer = customers.find((c) => c.id === selectedCustomerId);
    const customerName = matchedCustomer ? matchedCustomer.name : 'Walk-in Customer (සාමාන්‍ය පාරිභෝගිකයා)';
    const customerPhone = matchedCustomer ? matchedCustomer.phone : undefined;

    const isCredit = cartPaymentMethod === 'CREDIT';
    const paidAmount = isCredit ? 0 : totalAmount;
    const remainingBalance = isCredit ? totalAmount : 0;
    const changeAmount = !isCredit && tenderedAmount > totalAmount ? tenderedAmount - totalAmount : 0;

    const invoiceNumber = generateInvoiceNumber(sales.length + 1);

    const saleId = `sale_${Date.now()}`;
    const newSale: Sale = {
      id: saleId,
      businessId: business.id,
      invoiceNumber,
      customerId: selectedCustomerId || undefined,
      customerName,
      customerPhone,
      items: cart.map((item, idx) => ({
        id: `item_${saleId}_${idx}`,
        saleId,
        productId: item.product.id,
        productName: item.product.name,
        sku: item.product.sku,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        costPrice: item.costPrice,
        subtotal: item.subtotal,
        profit: item.subtotal - item.costPrice * item.quantity,
      })),
      subtotal,
      discountType: cartDiscountType,
      discountValue: cartDiscountValue,
      discountAmount,
      totalAmount,
      costTotal,
      profit,
      paymentMethod: cartPaymentMethod,
      paymentStatus: isCredit ? 'CREDIT' : 'PAID',
      paidAmount,
      remainingBalance,
      tenderedAmount: tenderedAmount > 0 ? tenderedAmount : totalAmount,
      changeAmount,
      notes: cartNotes,
      isVoided: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // 1. Add Sale
    setSales((prev) => [newSale, ...prev]);

    // 2. Reduce Stock & Record Movements
    const newMovements: StockMovement[] = [];
    setProducts((prev) =>
      prev.map((p) => {
        const cartItem = cart.find((item) => item.product.id === p.id);
        if (!cartItem) return p;

        const previousStock = p.stockQuantity;
        const newStock = Math.max(0, previousStock - cartItem.quantity);

        newMovements.push({
          id: `mov_${Date.now()}_${p.id}`,
          businessId: business.id,
          productId: p.id,
          productName: p.name,
          type: 'SALE',
          quantity: -cartItem.quantity,
          previousStock,
          newStock,
          reason: `විකිණීම ${invoiceNumber} (Sale)`,
          referenceId: saleId,
          date: new Date().toISOString(),
          createdAt: new Date().toISOString(),
        });

        return {
          ...p,
          stockQuantity: newStock,
          updatedAt: new Date().toISOString(),
        };
      })
    );

    if (newMovements.length > 0) {
      setStockMovements((prev) => [...newMovements, ...prev]);
    }

    // 3. Update Customer records if credit / attached
    if (selectedCustomerId) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === selectedCustomerId
            ? {
                ...c,
                totalPurchases: c.totalPurchases + totalAmount,
                outstandingCredit: isCredit ? c.outstandingCredit + totalAmount : c.outstandingCredit,
                updatedAt: new Date().toISOString(),
              }
            : c
        )
      );
    }

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#0d9488', '#14b8a6', '#f59e0b', '#3b82f6'],
      });
    } catch {
      // Confetti fallback
    }

    // Reset Cart
    clearCart();

    return newSale;
  }, [
    cart,
    cartDiscountType,
    cartDiscountValue,
    cartPaymentMethod,
    tenderedAmount,
    cartNotes,
    customers,
    selectedCustomerId,
    sales.length,
    business.id,
    clearCart,
  ]);

  // Void Sale
  const voidSale = useCallback(
    (saleId: string, reason?: string): boolean => {
      const targetSale = sales.find((s) => s.id === saleId && !s.isVoided);
      if (!targetSale) return false;

      // 1. Mark sale as voided
      setSales((prev) =>
        prev.map((s) => (s.id === saleId ? { ...s, isVoided: true, paymentStatus: 'VOID', updatedAt: new Date().toISOString() } : s))
      );

      // 2. Restore stock
      const restoreMovements: StockMovement[] = [];
      setProducts((prev) =>
        prev.map((p) => {
          const item = targetSale.items.find((i) => i.productId === p.id);
          if (!item) return p;

          const previousStock = p.stockQuantity;
          const newStock = previousStock + item.quantity;

          restoreMovements.push({
            id: `mov_void_${Date.now()}_${p.id}`,
            businessId: business.id,
            productId: p.id,
            productName: p.name,
            type: 'VOID_RESTORE',
            quantity: item.quantity,
            previousStock,
            newStock,
            reason: reason || `අවලංගු කිරීම ${targetSale.invoiceNumber} (Void Sale)`,
            referenceId: saleId,
            date: new Date().toISOString(),
            createdAt: new Date().toISOString(),
          });

          return { ...p, stockQuantity: newStock, updatedAt: new Date().toISOString() };
        })
      );

      if (restoreMovements.length > 0) {
        setStockMovements((prev) => [...restoreMovements, ...prev]);
      }

      // 3. Rollback customer balance
      if (targetSale.customerId) {
        setCustomers((prev) =>
          prev.map((c) => {
            if (c.id !== targetSale.customerId) return c;
            return {
              ...c,
              totalPurchases: Math.max(0, c.totalPurchases - targetSale.totalAmount),
              outstandingCredit:
                targetSale.paymentMethod === 'CREDIT'
                  ? Math.max(0, c.outstandingCredit - targetSale.totalAmount)
                  : c.outstandingCredit,
              updatedAt: new Date().toISOString(),
            };
          })
        );
      }

      return true;
    },
    [sales, business.id]
  );

  // Metrics Calculation
  const metrics: DashboardMetrics = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];

    const validSales = sales.filter((s) => !s.isVoided);
    const validExpenses = expenses.filter((e) => !e.isDeleted);
    const activeProducts = products.filter((p) => !p.isDeleted);
    const activeCustomers = customers.filter((c) => !c.isDeleted);

    // Today's Sales
    const todaySalesList = validSales.filter((s) => s.createdAt.startsWith(todayStr));
    const todaySales = todaySalesList.reduce((acc, s) => acc + s.totalAmount, 0);
    const todaySalesCount = todaySalesList.length;
    const todayCostOfGoods = todaySalesList.reduce((acc, s) => acc + s.costTotal, 0);
    const todayGrossProfit = todaySales - todayCostOfGoods;

    // Today's Expenses
    const todayExpensesList = validExpenses.filter((e) => e.date.startsWith(todayStr));
    const todayExpenses = todayExpensesList.reduce((acc, e) => acc + e.amount, 0);
    const todayNetProfit = todayGrossProfit - todayExpenses;

    // Outstanding Credit
    const outstandingCredit = activeCustomers.reduce((acc, c) => acc + c.outstandingCredit, 0);

    // Stock Status
    const lowStockProducts = activeProducts.filter((p) => p.stockQuantity > 0 && p.stockQuantity <= p.lowStockLimit);
    const lowStockCount = lowStockProducts.length;
    const outOfStockCount = activeProducts.filter((p) => p.stockQuantity <= 0).length;

    // Top Selling Products
    const productSalesMap: Record<string, { product: Product; totalQuantity: number; totalRevenue: number }> = {};
    validSales.forEach((sale) => {
      sale.items.forEach((item) => {
        const prod = activeProducts.find((p) => p.id === item.productId);
        if (prod) {
          if (!productSalesMap[prod.id]) {
            productSalesMap[prod.id] = { product: prod, totalQuantity: 0, totalRevenue: 0 };
          }
          productSalesMap[prod.id].totalQuantity += item.quantity;
          productSalesMap[prod.id].totalRevenue += item.subtotal;
        }
      });
    });

    const topSellingProducts = Object.values(productSalesMap)
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 5);

    return {
      todaySales,
      todaySalesCount,
      todayExpenses,
      todayCostOfGoods,
      todayGrossProfit,
      todayNetProfit,
      outstandingCredit,
      lowStockCount,
      outOfStockCount,
      recentSales: validSales.slice(0, 8),
      lowStockProducts,
      topSellingProducts,
    };
  }, [sales, expenses, products, customers]);

  // Demo Data & Backup
  const loadDemoData = useCallback(() => {
    storage.loadDemoData();
    setBusiness(storage.getBusiness() || defaultBusiness);
    setProducts(storage.getProducts());
    setCategories(storage.getCategories());
    setCustomers(storage.getCustomers());
    setExpenses(storage.getExpenses());
    setSales(storage.getSales());
    setStockMovements(storage.getStockMovements());
    setIsOnboarded(true);
  }, []);

  const clearAllData = useCallback(() => {
    storage.clearAllData();
    setBusiness(defaultBusiness);
    setSettings(defaultSettings);
    setProducts([]);
    setCategories(defaultCategories);
    setCustomers([]);
    setSales([]);
    setExpenses([]);
    setPayments([]);
    setStockMovements([]);
    setIsOnboarded(false);
    setIsPinLocked(false);
  }, []);

  const exportBackup = useCallback(() => {
    return storage.exportBackupJson();
  }, []);

  const restoreBackup = useCallback((jsonString: string) => {
    const res = storage.restoreBackupJson(jsonString);
    if (res.success) {
      setBusiness(storage.getBusiness() || defaultBusiness);
      setSettings(storage.getSettings());
      setProducts(storage.getProducts());
      setCategories(storage.getCategories());
      setCustomers(storage.getCustomers());
      setSales(storage.getSales());
      setExpenses(storage.getExpenses());
      setPayments(storage.getPayments());
      setStockMovements(storage.getStockMovements());
      setIsOnboarded(true);
    }
    return res;
  }, []);

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        lang,
        setLang,
        isSearchOpen,
        setIsSearchOpen,
        isPinLocked,
        isLocked,
        unlockApp,
        lockApp,
        isOnboarded,
        isFirstTimeUser,
        completeOnboarding,
        isDarkMode,
        toggleDarkMode,
        business,
        updateBusiness,
        settings,
        updateSettings,
        products,
        categories,
        customers,
        sales,
        expenses,
        payments,
        stockMovements,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        selectedCustomerId,
        setSelectedCustomerId,
        cartDiscountType,
        setCartDiscountType,
        cartDiscountValue,
        setCartDiscountValue,
        cartPaymentMethod,
        setCartPaymentMethod,
        tenderedAmount,
        setTenderedAmount,
        cartNotes,
        setCartNotes,
        completeSale,
        voidSale,
        addProduct,
        updateProduct,
        deleteProduct,
        adjustProductStock,
        adjustStock,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        recordCustomerPayment,
        addExpense,
        updateExpense,
        deleteExpense,
        addCategory,
        metrics,
        loadDemoData,
        clearAllData,
        exportBackup,
        restoreBackup,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
