/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { PinLockScreen } from './components/common/PinLockScreen';
import { OnboardingFlow } from './components/onboarding/OnboardingFlow';
import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

// Screen Views
import { HomeDashboard } from './components/dashboard/HomeDashboard';
import { QuickSaleScreen } from './components/pos/QuickSaleScreen';
import { ProductListScreen } from './components/inventory/ProductListScreen';
import { CustomerListScreen } from './components/customers/CustomerListScreen';
import { ExpenseScreen } from './components/expenses/ExpenseScreen';
import { ReportsScreen } from './components/reports/ReportsScreen';
import { InvoiceListScreen } from './components/invoices/InvoiceListScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';

const MainAppContent: React.FC = () => {
  const { isFirstTimeUser, isLocked, activeTab, setActiveTab, isSearchOpen, setIsSearchOpen } = useApp();

  // Android Hardware Back Button Handling
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let isSubscribed = true;
    const setupListener = async () => {
      const backListener = await CapApp.addListener('backButton', () => {
        if (isSearchOpen) {
          setIsSearchOpen(false);
        } else if (activeTab !== 'home' && activeTab !== 'dashboard') {
          setActiveTab('home');
        } else {
          CapApp.exitApp();
        }
      });

      if (!isSubscribed) {
        backListener.remove();
      }
      return backListener;
    };

    const listenerPromise = setupListener();

    return () => {
      isSubscribed = false;
      listenerPromise.then(l => l?.remove());
    };
  }, [isSearchOpen, setIsSearchOpen, activeTab, setActiveTab]);

  // 1. If First Time User, show Onboarding and Business setup
  if (isFirstTimeUser) {
    return <OnboardingFlow />;
  }

  // 2. If Locked by Security PIN, show PIN screen
  if (isLocked) {
    return <PinLockScreen />;
  }

  // 3. Main Business Management Dashboard
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-white">
      {/* Top App Header */}
      <Header />

      {/* Main Screen View Content */}
      <main className="flex-1 min-h-0">
        {(activeTab === 'home' || activeTab === 'dashboard') && <HomeDashboard />}
        {activeTab === 'sales' && <QuickSaleScreen />}
        {activeTab === 'products' && <ProductListScreen />}
        {activeTab === 'customers' && <CustomerListScreen />}
        {activeTab === 'expenses' && <ExpenseScreen />}
        {activeTab === 'reports' && <ReportsScreen />}
        {activeTab === 'invoices' && <InvoiceListScreen />}
        {activeTab === 'settings' && <SettingsScreen />}
      </main>

      {/* Bottom Sticky Navigation */}
      <BottomNav />

      {/* Global Quick Search Modal */}
      <GlobalSearchModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}

