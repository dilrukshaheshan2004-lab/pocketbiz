export type Language = 'si' | 'en';

export type ThemeMode = 'light' | 'dark' | 'system';

export type CurrencyCode = 'LKR' | 'USD' | 'EUR' | 'GBP' | 'INR' | 'AED' | 'SAR';

export type PaymentMethod = 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'CREDIT';

export type PaymentStatus = 'PAID' | 'PARTIAL' | 'CREDIT' | 'VOID' | 'VOIDED';

export type StockMovementType =
  | 'PURCHASE'
  | 'SALE'
  | 'ADJUSTMENT'
  | 'ADJUST'
  | 'RETURN'
  | 'VOID_RESTORE'
  | 'RESTOCK'
  | 'DAMAGE'
  | 'EXPIRED'
  | 'INITIAL';

export type StockStatus = 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK';

export interface Business {
  id: string;
  name: string;
  ownerName: string;
  phone: string;
  address: string;
  currency: CurrencyCode;
  currencySymbol: string;
  logoUrl?: string;
  taxNumber?: string;
  email?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  businessId: string;
  name: string;
  nameSi?: string;
  icon?: string;
  color?: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  nameSi?: string;
  sku: string;
  category: string;
  sellingPrice: number;
  costPrice: number;
  stockQuantity: number;
  lowStockLimit: number;
  unit: string; // 'pcs', 'kg', 'g', 'l', 'ml', 'packet', 'bottle', 'box'
  imageUrl?: string;
  barcode?: string;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  creditLimit?: number;
  totalPurchases: number;
  outstandingCredit: number;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  discount: number;
  discountType: 'percentage' | 'fixed';
  subtotal: number;
}

export interface SaleItem {
  id: string;
  saleId: string;
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  subtotal: number;
  profit: number;
}

export interface Sale {
  id: string;
  businessId: string;
  invoiceNumber: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  items: SaleItem[];
  subtotal: number;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  discountAmount: number;
  totalAmount: number;
  costTotal: number;
  profit: number; // Revenue - COGS
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paidAmount: number;
  remainingBalance: number;
  tenderedAmount?: number;
  changeAmount?: number;
  changeDue?: number;
  notes?: string;
  isVoided: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  businessId: string;
  title: string;
  amount: number;
  category: 'Rent' | 'Electricity' | 'Water' | 'Transport' | 'Salary' | 'Stock Purchase' | 'Marketing' | 'Maintenance' | 'Tea & Meals' | 'Other' | string;
  date: string;
  notes?: string;
  receiptUrl?: string;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  businessId: string;
  saleId?: string;
  customerId: string;
  customerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
  date: string;
  createdAt: string;
}

export interface StockMovement {
  id: string;
  businessId: string;
  productId: string;
  productName: string;
  type: StockMovementType;
  quantity: number;
  previousStock?: number;
  previousQuantity?: number;
  newStock?: number;
  newQuantity?: number;
  reason?: string;
  referenceId?: string;
  date?: string;
  createdAt: string;
}

export interface AppSettings {
  language: Language;
  theme: ThemeMode;
  pinEnabled: boolean;
  isPinEnabled?: boolean;
  pinCode?: string | null;
  pinHash?: string;
  notificationsEnabled?: boolean;
  lowStockAlerts?: boolean;
  creditDueAlerts?: boolean;
  allowNegativeStock: boolean;
  printThermalReceipt?: boolean;
  autoGenerateInvoiceNumber?: boolean;
  lastBackupDate?: string;
  isProUnlocked?: boolean;
  soundEnabled?: boolean;
  invoiceFooterNote?: string;
}

export interface DashboardMetrics {
  todaySales: number;
  todaySalesCount: number;
  todayExpenses: number;
  todayCostOfGoods: number;
  todayGrossProfit: number;
  todayNetProfit: number;
  outstandingCredit: number;
  lowStockCount: number;
  outOfStockCount: number;
  recentSales: Sale[];
  lowStockProducts: Product[];
  topSellingProducts: { product: Product; totalQuantity: number; totalRevenue: number }[];
}

export type ActiveTab = 'dashboard' | 'home' | 'sales' | 'products' | 'customers' | 'expenses' | 'reports' | 'invoices' | 'settings';

