import React, { useState, useMemo } from 'react';
import {
  FileText,
  Search,
  Eye,
  Printer,
  Download,
  Share2,
  Ban,
  Filter,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShoppingBag,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Sale } from '../../types';
import { ReceiptModal } from '../modals/ReceiptModal';

export const InvoiceListScreen: React.FC = () => {
  const { sales, voidSale, business, lang, setActiveTab } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<'ALL' | 'PAID' | 'CREDIT' | 'VOIDED'>('ALL');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);

  const filteredSales = useMemo(() => {
    return sales
      .filter((s) => {
        const q = searchQuery.trim().toLowerCase();
        const matchesQuery =
          !q ||
          s.invoiceNumber.toLowerCase().includes(q) ||
          s.customerName.toLowerCase().includes(q) ||
          (s.customerPhone && s.customerPhone.includes(q));

        let matchesPayment = true;
        if (paymentFilter === 'PAID') matchesPayment = !s.isVoided && s.paymentStatus === 'PAID';
        if (paymentFilter === 'CREDIT') matchesPayment = !s.isVoided && s.paymentStatus === 'CREDIT';
        if (paymentFilter === 'VOIDED') matchesPayment = s.isVoided;

        return matchesQuery && matchesPayment;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [sales, searchQuery, paymentFilter]);

  const handleVoid = (sale: Sale) => {
    if (sale.isVoided) return;
    const reason = window.prompt(
      lang === 'si'
        ? `Invoice #${sale.invoiceNumber} අවලංගු කිරීමට (Void) හේතුව ඇතුළත් කරන්න:`
        : `Enter reason for voiding Invoice #${sale.invoiceNumber}:`
    );
    if (reason !== null) {
      voidSale(sale.id, reason || 'Cancelled by merchant');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 pb-24 space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-600" />
            <span>{t('invoicesTitle', lang)}</span>
            <span className="text-xs font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full">
              {sales.length}
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            නිකුත් කරන ලද බිල්පත් සහ ලදුපත් ඉතිහාසය
          </p>
        </div>

        <button
          onClick={() => setActiveTab('sales')}
          className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors self-start sm:self-auto"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>{t('addSale', lang)}</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchInvoicePlaceholder', lang)}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Status Filter */}
        <div className="flex bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 text-xs">
          {[
            { id: 'ALL', label: t('all', lang) },
            { id: 'PAID', label: 'ගෙවා ඇත (Paid)' },
            { id: 'CREDIT', label: 'ණය (Credit)' },
            { id: 'VOIDED', label: 'අවලංගු (Void)' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setPaymentFilter(item.id as any)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                paymentFilter === item.id
                  ? 'bg-teal-600 text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Invoices List */}
      {filteredSales.length === 0 ? (
        <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 p-12 text-center">
          <FileText className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('noInvoices', lang)}</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">{t('noInvoicesDesc', lang)}</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700/80 divide-y divide-slate-100 dark:divide-slate-700/60 shadow-xs overflow-hidden">
          {filteredSales.map((sale) => {
            return (
              <div
                key={sale.id}
                className={`p-4 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors ${
                  sale.isVoided ? 'opacity-50 bg-slate-50/50' : ''
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-sm text-slate-900 dark:text-slate-100">
                      {sale.invoiceNumber}
                    </span>
                    {sale.isVoided ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200">
                        {t('statusVoided', lang)}
                      </span>
                    ) : (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          sale.paymentStatus === 'PAID'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                            : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                        }`}
                      >
                        {sale.paymentMethod}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 mt-1">
                    {sale.customerName} • {formatDate(sale.createdAt, lang)} • {sale.items.length} items
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <span className="font-black text-sm sm:text-base text-slate-900 dark:text-slate-100 block">
                      {formatCurrency(sale.totalAmount, business.currency, lang)}
                    </span>
                    {sale.profit > 0 && !sale.isVoided && (
                      <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 block">
                        +ලාභය {formatCurrency(sale.profit, business.currency, lang)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSelectedSale(sale)}
                      className="px-3 py-1.5 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                      title="View Invoice / Print"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{t('viewInvoice', lang)}</span>
                    </button>

                    {!sale.isVoided && (
                      <button
                        type="button"
                        onClick={() => handleVoid(sale)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                        title={t('voidSale', lang)}
                      >
                        <Ban className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Invoice / Receipt View Modal */}
      {selectedSale && (
        <ReceiptModal
          sale={selectedSale}
          onClose={() => setSelectedSale(null)}
        />
      )}
    </div>
  );
};
