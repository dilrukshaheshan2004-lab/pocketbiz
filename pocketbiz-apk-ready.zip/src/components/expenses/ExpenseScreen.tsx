import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Calendar,
  Tag,
  Edit2,
  Trash2,
  PieChart,
  DollarSign,
  Filter,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Expense } from '../../types';
import { AddEditExpenseModal } from '../modals/AddEditExpenseModal';

export const ExpenseScreen: React.FC = () => {
  const { expenses, deleteExpense, business, lang } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [timeFilter, setTimeFilter] = useState<'today' | 'thisMonth' | 'all'>('thisMonth');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

  const activeExpenses = useMemo(() => {
    return expenses.filter((e) => !e.isDeleted);
  }, [expenses]);

  const filteredExpenses = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const thisMonthStr = todayStr.substring(0, 7);

    return activeExpenses.filter((e) => {
      const matchesCategory = selectedCategory === 'ALL' || e.category === selectedCategory;
      const q = searchQuery.trim().toLowerCase();
      const matchesQuery = !q || e.title.toLowerCase().includes(q) || (e.notes && e.notes.toLowerCase().includes(q));

      let matchesTime = true;
      if (timeFilter === 'today') matchesTime = e.date.startsWith(todayStr);
      if (timeFilter === 'thisMonth') matchesTime = e.date.startsWith(thisMonthStr);

      return matchesCategory && matchesQuery && matchesTime;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [activeExpenses, selectedCategory, searchQuery, timeFilter]);

  const totalFilteredAmount = useMemo(() => {
    return filteredExpenses.reduce((acc, e) => acc + e.amount, 0);
  }, [filteredExpenses]);

  // Category breakdown for insights
  const categoryBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    filteredExpenses.forEach((e) => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filteredExpenses]);

  const handleDelete = (id: string, title: string) => {
    if (window.confirm(`"${title}" වියදම මකා දැමීමට ඔබට විශ්වාසද?`)) {
      deleteExpense(id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 pb-24 space-y-4">
      {/* Top Banner with Total Expense */}
      <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white p-5 rounded-2xl border border-rose-800/60 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-rose-400" />
            <h2 className="text-lg sm:text-xl font-bold tracking-tight">{t('expensesTitle', lang)}</h2>
            <span className="text-xs font-bold px-2 py-0.5 bg-rose-950/80 text-rose-300 rounded-full border border-rose-700">
              {filteredExpenses.length} සටහන්
            </span>
          </div>
          <p className="text-xs text-rose-200/80 mt-1">
            ශුද්ධ ලාභය නිවැරදිව ගණනය කිරීම සඳහා ව්‍යාපාර වියදම් සටහන් කරන්න
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-rose-950/60 border border-rose-700/80 rounded-xl p-2.5 px-4 text-right">
            <span className="text-[10px] text-rose-300 block font-semibold">
              {t('totalExpenses', lang)}
            </span>
            <span className="font-extrabold text-base sm:text-lg text-white">
              {formatCurrency(totalFilteredAmount, business.currency, lang)}
            </span>
          </div>

          <button
            id="add-expense-main-btn"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-white text-rose-900 hover:bg-rose-50 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addExpenseTitle', lang)}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search', lang) + ' (වියදමේ විස්තරය...)'}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-rose-500"
          />
        </div>

        {/* Time Tabs */}
        <div className="flex bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 text-xs">
          {[
            { id: 'today', label: t('timeToday', lang) },
            { id: 'thisMonth', label: t('timeThisMonth', lang) },
            { id: 'all', label: t('timeAll', lang) },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setTimeFilter(item.id as any)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                timeFilter === item.id
                  ? 'bg-rose-600 text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Category Dropdown */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
        >
          <option value="ALL">සියලු වියදම් කාණ්ඩ</option>
          <option value="Rent">{t('catRent', lang)}</option>
          <option value="Electricity">{t('catElectricity', lang)}</option>
          <option value="Water">{t('catWater', lang)}</option>
          <option value="Transport">{t('catTransport', lang)}</option>
          <option value="Salary">{t('catSalary', lang)}</option>
          <option value="Stock Purchase">{t('catStockPurchase', lang)}</option>
          <option value="Marketing">{t('catMarketing', lang)}</option>
          <option value="Maintenance">{t('catMaintenance', lang)}</option>
          <option value="Tea & Meals">{t('catTeaMeals', lang)}</option>
          <option value="Other">{t('catOther', lang)}</option>
        </select>
      </div>

      {/* Category Breakdown Chips */}
      {categoryBreakdown.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {categoryBreakdown.map(([cat, amt]) => (
            <div
              key={cat}
              className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 shrink-0 flex items-center gap-2 shadow-2xs text-xs"
            >
              <span className="font-semibold text-slate-700 dark:text-slate-300">{cat}</span>
              <span className="font-bold text-rose-600 dark:text-rose-400">
                {formatCurrency(amt, business.currency, lang)}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Expense List */}
      {filteredExpenses.length === 0 ? (
        <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 p-12 text-center">
          <Receipt className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('noExpenses', lang)}</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">{t('noExpensesDesc', lang)}</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="mt-4 px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addExpenseTitle', lang)}</span>
          </button>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700/80 divide-y divide-slate-100 dark:divide-slate-700/60 shadow-xs overflow-hidden">
          {filteredExpenses.map((expense) => (
            <div
              key={expense.id}
              className="p-4 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 truncate">
                    {expense.title}
                  </h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                    {expense.category}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                  <span>{formatDate(expense.date, lang)}</span>
                  {expense.notes && <span>• {expense.notes}</span>}
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="font-extrabold text-sm sm:text-base text-rose-600 dark:text-rose-400">
                  -{formatCurrency(expense.amount, business.currency, lang)}
                </span>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setEditingExpense(expense)}
                    className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
                    title={t('edit', lang)}
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(expense.id, expense.title)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                    title={t('delete', lang)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      {isAddModalOpen && (
        <AddEditExpenseModal
          onClose={() => setIsAddModalOpen(false)}
        />
      )}

      {editingExpense && (
        <AddEditExpenseModal
          expenseToEdit={editingExpense}
          onClose={() => setEditingExpense(null)}
        />
      )}
    </div>
  );
};
