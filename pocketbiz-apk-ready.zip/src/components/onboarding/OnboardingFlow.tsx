import React, { useState } from 'react';
import { ArrowRight, Store, CheckCircle, Sparkles, Phone, MapPin, User, DollarSign, Database } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { Business, CurrencyCode } from '../../types';

export const OnboardingFlow: React.FC = () => {
  const { completeOnboarding, loadDemoData, lang, setLang } = useApp();
  const [step, setStep] = useState<number>(0);

  // Business Form State
  const [name, setName] = useState('නිමල් ස්ටෝර්ස්');
  const [ownerName, setOwnerName] = useState('කසුන් පෙරේරා');
  const [phone, setPhone] = useState('071 234 5678');
  const [address, setAddress] = useState('නො. 45, ප්‍රධාන වීදිය, මහරගම');
  const [currency, setCurrency] = useState<CurrencyCode>('LKR');
  const [logoIcon, setLogoIcon] = useState('🏪');

  const logoPresets = ['🏪', '🛒', '🛍️', '🍞', '🍰', '👗', '📱', '🔧', '📦', '☕', '🌾', '🧼'];

  const onboardingSlides = [
    {
      icon: '💼',
      title: t('onboarding1Title', lang),
      desc: t('onboarding1Desc', lang),
      color: 'from-teal-500 to-emerald-600',
    },
    {
      icon: '📊',
      title: t('onboarding2Title', lang),
      desc: t('onboarding2Desc', lang),
      color: 'from-blue-500 to-indigo-600',
    },
    {
      icon: '📈',
      title: t('onboarding3Title', lang),
      desc: t('onboarding3Desc', lang),
      color: 'from-amber-500 to-orange-600',
    },
  ];

  const handleFinishSetup = (e: React.FormEvent) => {
    e.preventDefault();
    const newBiz: Business = {
      id: `biz_${Date.now()}`,
      name: name.trim() || 'PocketBiz Shop',
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      address: address.trim(),
      currency,
      currencySymbol: currency === 'LKR' ? 'Rs.' : currency,
      logoUrl: logoIcon,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    completeOnboarding(newBiz);
  };

  const handleQuickDemoSetup = () => {
    loadDemoData();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 text-white flex flex-col justify-between p-6">
      {/* Top Language Toggle */}
      <div className="flex justify-between items-center max-w-md mx-auto w-full pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center font-bold text-white shadow-md shadow-teal-500/30">
            PB
          </div>
          <span className="font-bold text-lg tracking-tight">PocketBiz</span>
        </div>

        <button
          onClick={() => setLang(lang === 'si' ? 'en' : 'si')}
          className="text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 hover:bg-slate-700 text-teal-400 transition-colors"
        >
          {lang === 'si' ? 'English ට මාරුවන්න' : 'Switch to සිංහල'}
        </button>
      </div>

      {/* Main Slide Carousel or Setup Screen */}
      <div className="max-w-md mx-auto w-full my-auto py-8">
        {step < 3 ? (
          <div className="text-center animate-in fade-in zoom-in-95 duration-300">
            {/* Visual Icon */}
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr shadow-2xl flex items-center justify-center text-5xl mx-auto mb-8 border border-white/10">
              {onboardingSlides[step].icon}
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug mb-4">
              {onboardingSlides[step].title}
            </h2>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed px-2 mb-8">
              {onboardingSlides[step].desc}
            </p>

            {/* Dots */}
            <div className="flex items-center justify-center gap-2 mb-8">
              {[0, 1, 2].map((idx) => (
                <div
                  key={idx}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    step === idx ? 'w-8 bg-teal-400' : 'w-2 bg-slate-700'
                  }`}
                />
              ))}
            </div>

            <div className="space-y-3">
              <button
                id="onboarding-next-btn"
                onClick={() => setStep(step + 1)}
                className="w-full py-3.5 bg-teal-500 hover:bg-teal-400 active:scale-98 text-slate-950 font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 transition-all text-base"
              >
                <span>{step === 2 ? t('getStarted', lang) : t('next', lang)}</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {step < 2 && (
                <button
                  id="onboarding-skip-btn"
                  onClick={() => setStep(3)}
                  className="text-xs text-slate-400 hover:text-slate-200 py-1"
                >
                  {t('skip', lang)}
                </button>
              )}
            </div>
          </div>
        ) : (
          /* Step 3: Business Setup Form */
          <div className="bg-slate-800/90 border border-slate-700/80 rounded-3xl p-6 shadow-2xl backdrop-blur-md animate-in fade-in duration-300">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto mb-2 border border-teal-500/30">
                <Store className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-white">{t('businessSetupTitle', lang)}</h2>
              <p className="text-xs text-slate-400 mt-1">{t('businessSetupDesc', lang)}</p>
            </div>

            <form onSubmit={handleFinishSetup} className="space-y-4">
              {/* Business Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('businessName', lang)} *
                </label>
                <div className="relative">
                  <Store className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t('businessNamePlaceholder', lang)}
                    className="w-full bg-slate-900/80 border border-slate-700 focus:border-teal-500 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Owner Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('ownerName', lang)}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="text"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder={t('ownerNamePlaceholder', lang)}
                      className="w-full bg-slate-900/80 border border-slate-700 focus:border-teal-500 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('phoneNumber', lang)}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="071 234 5678"
                      className="w-full bg-slate-900/80 border border-slate-700 focus:border-teal-500 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('businessAddress', lang)}
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder={t('businessAddressPlaceholder', lang)}
                    className="w-full bg-slate-900/80 border border-slate-700 focus:border-teal-500 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Currency & Icon */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('currency', lang)}
                  </label>
                  <div className="relative">
                    <DollarSign className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <select
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                      className="w-full bg-slate-900/80 border border-slate-700 focus:border-teal-500 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white focus:outline-none"
                    >
                      <option value="LKR">LKR (රු. Sri Lanka)</option>
                      <option value="USD">USD ($)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="GBP">GBP (£)</option>
                      <option value="INR">INR (₹)</option>
                      <option value="AED">AED</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('businessLogo', lang)}
                  </label>
                  <div className="flex gap-1.5 overflow-x-auto pb-1">
                    {logoPresets.slice(0, 6).map((icon) => (
                      <button
                        type="button"
                        key={icon}
                        onClick={() => setLogoIcon(icon)}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 border transition-all ${
                          logoIcon === icon
                            ? 'bg-teal-500/30 border-teal-400 scale-105'
                            : 'bg-slate-900/60 border-slate-700'
                        }`}
                      >
                        {icon}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Submit Action */}
              <button
                type="submit"
                id="finish-setup-btn"
                className="w-full py-3.5 bg-teal-500 hover:bg-teal-400 active:scale-98 text-slate-950 font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 transition-all text-base mt-2"
              >
                <CheckCircle className="w-5 h-5" />
                <span>{t('finishSetup', lang)}</span>
              </button>

              {/* Demo Data Option */}
              <div className="pt-2 text-center border-t border-slate-700/60">
                <button
                  type="button"
                  onClick={handleQuickDemoSetup}
                  className="inline-flex items-center gap-1.5 text-xs text-teal-400 hover:text-teal-300 font-semibold"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>ආදර්ශ වෙළඳසැල් Demo දත්ත සමඟ ආරම්භ කරන්න</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-slate-500 max-w-md mx-auto w-full">
        <p>PocketBiz • 100% නොබැඳිව (Offline) ක්‍රියාත්මක වේ • No Internet Needed</p>
      </div>
    </div>
  );
};
