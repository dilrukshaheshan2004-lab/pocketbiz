import React, { useState, useMemo } from 'react';
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  User,
  CreditCard,
  Banknote,
  Building2,
  Tag,
  CheckCircle2,
  Percent,
  X,
  Sparkles,
  AlertCircle,
  Package,
  Layers,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency } from '../../utils/formatters';
import { Product, PaymentMethod, Sale } from '../../types';
import { ReceiptModal } from '../modals/ReceiptModal';
import { AddEditCustomerModal } from '../modals/AddEditCustomerModal';

export const QuickSaleScreen: React.FC = () => {
  const {
    products,
    categories,
    customers,
    cart,
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    selectedCustomerId,
    setSelectedCustomerId,
    cartDiscountType,
    setCartDiscountType,
    cartDiscountValue,
    setCartDiscountValue,
    cartPaymentMethod,
    setCartPaymentMethod,
    tenderedAmount,
    setTenderedAmount,
    cartNotes,
    setCartNotes,
    completeSale,
    business,
    lang,
    settings,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [isMobileCartOpen, setIsMobileCartOpen] = useState(false);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (p.isDeleted) return false;
      const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
      const q = searchQuery.trim().toLowerCase();
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.nameSi && p.nameSi.toLowerCase().includes(q)) ||
        p.sku.toLowerCase().includes(q) ||
        (p.barcode && p.barcode.includes(q));
      return matchesCategory && matchesQuery;
    });
  }, [products, selectedCategory, searchQuery]);

  // Cart Calculations
  const subtotal = cart.reduce((acc, item) => acc + item.subtotal, 0);
  let discountAmount = 0;
  if (cartDiscountValue > 0) {
    if (cartDiscountType === 'percentage') {
      discountAmount = (subtotal * cartDiscountValue) / 100;
    } else {
      discountAmount = Math.min(cartDiscountValue, subtotal);
    }
  }
  const totalAmount = Math.max(0, subtotal - discountAmount);
  const changeDue = cartPaymentMethod === 'CASH' && tenderedAmount > totalAmount ? tenderedAmount - totalAmount : 0;

  const handleCheckout = () => {
    if (cart.length === 0) return;

    // Check for out of stock warning
    if (!settings.allowNegativeStock) {
      for (const item of cart) {
        if (item.quantity > item.product.stockQuantity) {
          alert(
            lang === 'si'
              ? `"${item.product.nameSi || item.product.name}" සඳහා ප්‍රමාණවත් තොග නොමැත! (ඉතිරිව ඇත්තේ ${item.product.stockQuantity})`
              : `Insufficient stock for "${item.product.name}"! (Only ${item.product.stockQuantity} available)`
          );
          return;
        }
      }
    }

    const sale = completeSale();
    if (sale) {
      setCompletedSale(sale);
      setIsMobileCartOpen(false);
    }
  };

  const handleQuickTender = (amount: number) => {
    setTenderedAmount(amount);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-3 pb-24 h-[calc(100vh-130px)] flex flex-col">
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-2 mb-3">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchProductPlaceholder', lang)}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-teal-500 shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Category Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
          <button
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedCategory === 'ALL'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            {t('allCategories', lang)}
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.name)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.name
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              {lang === 'si' && cat.nameSi ? cat.nameSi : cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Products Catalog (Left) + Cart & Checkout (Right) */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-0 overflow-hidden">
        {/* Products Grid (7 cols on Large) */}
        <div className="lg:col-span-7 flex flex-col min-h-0 overflow-y-auto pr-1">
          {filteredProducts.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 bg-white dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-center">
              <Package className="w-12 h-12 text-slate-300 dark:text-slate-600 mb-2" />
              <p className="font-bold text-sm text-slate-600 dark:text-slate-300">
                {t('noProducts', lang)}
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">{t('noProductsDesc', lang)}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 gap-2.5 pb-4">
              {filteredProducts.map((product) => {
                const inCart = cart.find((i) => i.product.id === product.id);
                const isOutOfStock = product.stockQuantity <= 0;
                const isLowStock = product.stockQuantity > 0 && product.stockQuantity <= product.lowStockLimit;

                return (
                  <div
                    key={product.id}
                    id={`pos-prod-${product.id}`}
                    onClick={() => {
                      if (!isOutOfStock || settings.allowNegativeStock) {
                        addToCart(product, 1);
                      }
                    }}
                    className={`relative p-3 rounded-2xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                      inCart
                        ? 'bg-teal-50/80 dark:bg-teal-950/40 border-teal-500 shadow-sm scale-[0.99]'
                        : isOutOfStock
                        ? 'bg-slate-100 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 opacity-60'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-teal-400 hover:shadow-sm'
                    }`}
                  >
                    {/* Cart Quantity Badge */}
                    {inCart && (
                      <span className="absolute -top-1.5 -right-1.5 bg-teal-600 text-white font-extrabold text-xs w-6 h-6 rounded-full flex items-center justify-center shadow-md">
                        {inCart.quantity}
                      </span>
                    )}

                    <div>
                      {/* Emoji or Image Icon */}
                      <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-700/60 flex items-center justify-center text-xl mb-2">
                        {product.imageUrl || '📦'}
                      </div>

                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug">
                        {product.nameSi || product.name}
                      </h4>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                        SKU: {product.sku}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-end justify-between gap-1">
                      <div>
                        <span className="font-extrabold text-xs sm:text-sm text-teal-700 dark:text-teal-300 block">
                          {formatCurrency(product.sellingPrice, business.currency, lang)}
                        </span>
                        <span
                          className={`text-[9px] font-bold ${
                            isOutOfStock
                              ? 'text-rose-600'
                              : isLowStock
                              ? 'text-amber-600'
                              : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {isOutOfStock
                            ? t('outOfStock', lang)
                            : `${product.stockQuantity} ${product.unit}`}
                        </span>
                      </div>

                      <button
                        type="button"
                        className="w-7 h-7 rounded-lg bg-teal-600 hover:bg-teal-500 text-white flex items-center justify-center shadow-xs shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Cart & Checkout Panel (5 cols on Large / Floating Bar on Mobile) */}
        <div className="hidden lg:flex lg:col-span-5 flex-col bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden h-full">
          {/* Cart Header */}
          <div className="p-3.5 border-b border-slate-100 dark:border-slate-700/80 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">
                {t('cart', lang)} ({cart.length})
              </h3>
            </div>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-[11px] font-semibold text-rose-600 hover:underline"
              >
                {t('clearCart', lang)}
              </button>
            )}
          </div>

          {/* Customer Selection Box */}
          <div className="p-3 border-b border-slate-100 dark:border-slate-700/80 bg-white dark:bg-slate-800">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <User className="w-4 h-4 text-slate-400 shrink-0" />
                <select
                  value={selectedCustomerId || ''}
                  onChange={(e) => setSelectedCustomerId(e.target.value || null)}
                  className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                >
                  <option value="">{t('walkInCustomer', lang)}</option>
                  {customers
                    .filter((c) => !c.isDeleted)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.outstandingCredit > 0 ? `(ණය: රු. ${c.outstandingCredit})` : ''}
                      </option>
                    ))}
                </select>
              </div>
              <button
                type="button"
                onClick={() => setIsCustomerModalOpen(true)}
                className="p-1.5 bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold hover:bg-teal-100"
                title={t('addCustomer', lang)}
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 divide-y divide-slate-100 dark:divide-slate-700/50">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                <ShoppingCart className="w-10 h-10 opacity-30 mb-2" />
                <p className="text-xs font-semibold">{t('cartEmpty', lang)}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{t('cartEmptyDesc', lang)}</p>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.product.id} className="pt-2 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-xs text-slate-900 dark:text-slate-100 truncate">
                      {item.product.nameSi || item.product.name}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      {formatCurrency(item.unitPrice, business.currency, lang)} x {item.quantity}
                    </p>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold text-xs"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-bold text-xs text-slate-900 dark:text-slate-100">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="w-6 h-6 rounded-lg bg-teal-600 hover:bg-teal-500 text-white flex items-center justify-center font-bold text-xs"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="text-right min-w-[64px] shrink-0">
                    <span className="font-bold text-xs text-slate-900 dark:text-slate-100">
                      {formatCurrency(item.subtotal, business.currency, lang)}
                    </span>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded-md"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Cart Footer: Discount, Payment Method & Checkout */}
          {cart.length > 0 && (
            <div className="p-3.5 border-t border-slate-100 dark:border-slate-700/80 bg-slate-50/80 dark:bg-slate-850 space-y-3">
              {/* Discount Input */}
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1 font-semibold">
                  <Tag className="w-3 h-3" />
                  {t('discount', lang)}:
                </span>
                <div className="flex items-center gap-1">
                  <div className="flex rounded-lg overflow-hidden border border-slate-300 dark:border-slate-600">
                    <button
                      type="button"
                      onClick={() => setCartDiscountType('percentage')}
                      className={`px-1.5 py-0.5 text-[10px] font-bold ${
                        cartDiscountType === 'percentage'
                          ? 'bg-teal-600 text-white'
                          : 'bg-white dark:bg-slate-700 text-slate-600'
                      }`}
                    >
                      %
                    </button>
                    <button
                      type="button"
                      onClick={() => setCartDiscountType('fixed')}
                      className={`px-1.5 py-0.5 text-[10px] font-bold ${
                        cartDiscountType === 'fixed'
                          ? 'bg-teal-600 text-white'
                          : 'bg-white dark:bg-slate-700 text-slate-600'
                      }`}
                    >
                      Rs.
                    </button>
                  </div>
                  <input
                    type="number"
                    min="0"
                    value={cartDiscountValue || ''}
                    onChange={(e) => setCartDiscountValue(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-16 bg-white dark:bg-slate-750 border border-slate-300 dark:border-slate-600 rounded-lg px-2 py-0.5 text-right font-bold text-xs focus:outline-none"
                  />
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <span className="block text-[11px] font-bold text-slate-500 mb-1.5">
                  {t('paymentMethod', lang)}
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: 'CASH', label: 'Cash', icon: <Banknote className="w-3.5 h-3.5" /> },
                    { id: 'CARD', label: 'Card', icon: <CreditCard className="w-3.5 h-3.5" /> },
                    { id: 'BANK_TRANSFER', label: 'Bank', icon: <Building2 className="w-3.5 h-3.5" /> },
                    { id: 'CREDIT', label: 'ණය (Credit)', icon: <Tag className="w-3.5 h-3.5" /> },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setCartPaymentMethod(m.id as PaymentMethod)}
                      className={`flex flex-col items-center justify-center p-1.5 rounded-xl border text-[10px] font-bold transition-all ${
                        cartPaymentMethod === m.id
                          ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {m.icon}
                      <span className="mt-0.5">{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tender Calculation for Cash */}
              {cartPaymentMethod === 'CASH' && (
                <div className="p-2 bg-teal-50/60 dark:bg-teal-950/30 rounded-xl border border-teal-200 dark:border-teal-800/60 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      {t('tenderedAmount', lang)}:
                    </span>
                    <input
                      type="number"
                      value={tenderedAmount || ''}
                      onChange={(e) => setTenderedAmount(parseFloat(e.target.value) || 0)}
                      placeholder={String(totalAmount)}
                      className="w-24 bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg px-2 py-0.5 text-right font-bold text-xs focus:outline-none"
                    />
                  </div>
                  {/* Quick Tender Buttons */}
                  <div className="flex gap-1 justify-end">
                    {[500, 1000, 2000, 5000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleQuickTender(amt)}
                        className="px-1.5 py-0.5 bg-white dark:bg-slate-800 hover:bg-teal-100 text-teal-800 dark:text-teal-300 font-bold text-[10px] rounded border border-teal-200 dark:border-teal-800"
                      >
                        +{amt}
                      </button>
                    ))}
                  </div>
                  {tenderedAmount > totalAmount && (
                    <div className="flex justify-between items-center text-xs font-bold text-teal-800 dark:text-teal-300 pt-1 border-t border-teal-200/60 dark:border-teal-800/60">
                      <span>{t('changeDue', lang)}:</span>
                      <span>{formatCurrency(changeDue, business.currency, lang)}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Total Row */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500 font-medium block">
                    {t('total', lang)}
                  </span>
                  <span className="text-lg font-black text-slate-900 dark:text-slate-100">
                    {formatCurrency(totalAmount, business.currency, lang)}
                  </span>
                </div>

                {/* Complete Sale CTA */}
                <button
                  type="button"
                  id="pos-complete-sale-btn"
                  onClick={handleCheckout}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white font-extrabold rounded-xl shadow-md shadow-teal-600/20 text-xs flex items-center gap-1.5 transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{t('completeSale', lang)}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Floating Cart Button & Bar */}
      {cart.length > 0 && (
        <div className="lg:hidden fixed bottom-16 left-4 right-4 z-30">
          <button
            onClick={() => setIsMobileCartOpen(true)}
            className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-3 px-4 rounded-2xl shadow-xl flex items-center justify-between animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-white text-teal-700 rounded-full flex items-center justify-center text-xs font-black">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </div>
              <span className="text-xs font-semibold">{t('cart', lang)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black">
                {formatCurrency(totalAmount, business.currency, lang)}
              </span>
              <span className="text-xs bg-teal-700 px-2.5 py-1 rounded-xl">
                {t('completeSale', lang)} →
              </span>
            </div>
          </button>
        </div>
      )}

      {/* Mobile Cart Drawer Modal */}
      {isMobileCartOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="absolute inset-0"
            onClick={() => setIsMobileCartOpen(false)}
          />
          <div className="relative bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 p-4 shadow-2xl max-w-lg mx-auto w-full z-10 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-teal-600" />
                {t('cart', lang)} ({cart.length})
              </h3>
              <button
                onClick={() => setIsMobileCartOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Customer Box */}
            <div className="py-2.5 border-b border-slate-100 dark:border-slate-800">
              <select
                value={selectedCustomerId || ''}
                onChange={(e) => setSelectedCustomerId(e.target.value || null)}
                className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
              >
                <option value="">{t('walkInCustomer', lang)}</option>
                {customers
                  .filter((c) => !c.isDeleted)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.outstandingCredit > 0 ? `(ණය: රු. ${c.outstandingCredit})` : ''}
                    </option>
                  ))}
              </select>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60"
                >
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                      {item.product.nameSi || item.product.name}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      {formatCurrency(item.unitPrice, business.currency, lang)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-700 text-xs font-bold"
                    >
                      -
                    </button>
                    <span className="font-bold text-xs w-4 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="w-6 h-6 rounded bg-teal-600 text-white text-xs font-bold"
                    >
                      +
                    </button>
                    <span className="font-bold text-xs text-slate-900 dark:text-slate-100 ml-2">
                      {formatCurrency(item.subtotal, business.currency, lang)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Payment Method & Checkout */}
            <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="grid grid-cols-4 gap-1">
                {['CASH', 'CARD', 'BANK_TRANSFER', 'CREDIT'].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setCartPaymentMethod(m as PaymentMethod)}
                    className={`py-1.5 rounded-lg text-[10px] font-bold border ${
                      cartPaymentMethod === m
                        ? 'bg-teal-600 text-white border-teal-600'
                        : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {m === 'CASH' ? 'Cash' : m === 'CARD' ? 'Card' : m === 'BANK_TRANSFER' ? 'Bank' : 'ණය'}
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">{t('total', lang)}</span>
                  <span className="text-base font-black text-slate-900 dark:text-slate-100">
                    {formatCurrency(totalAmount, business.currency, lang)}
                  </span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="px-6 py-2.5 bg-teal-600 text-white font-bold rounded-xl text-xs"
                >
                  {t('completeSale', lang)}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sale Receipt Modal */}
      {completedSale && (
        <ReceiptModal
          sale={completedSale}
          onClose={() => setCompletedSale(null)}
        />
      )}

      {/* Add Customer Modal */}
      {isCustomerModalOpen && (
        <AddEditCustomerModal
          onClose={() => setIsCustomerModalOpen(false)}
          onCustomerAdded={(newCust) => setSelectedCustomerId(newCust.id)}
        />
      )}
    </div>
  );
};
