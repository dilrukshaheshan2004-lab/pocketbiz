import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Phone,
  MessageSquare,
  DollarSign,
  AlertCircle,
  Clock,
  Send,
  Eye,
  Edit2,
  Trash2,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency } from '../../utils/formatters';
import { Customer } from '../../types';
import { AddEditCustomerModal } from '../modals/AddEditCustomerModal';
import { RecordPaymentModal } from '../modals/RecordPaymentModal';
import { CustomerDetailModal } from '../modals/CustomerDetailModal';

export const CustomerListScreen: React.FC = () => {
  const { customers, deleteCustomer, business, lang } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'WITH_CREDIT' | 'ZERO_CREDIT'>('ALL');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [paymentCustomer, setPaymentCustomer] = useState<Customer | null>(null);
  const [detailCustomer, setDetailCustomer] = useState<Customer | null>(null);

  const activeCustomers = useMemo(() => {
    return customers.filter((c) => !c.isDeleted);
  }, [customers]);

  const totalOutstandingCredit = useMemo(() => {
    return activeCustomers.reduce((acc, c) => acc + c.outstandingCredit, 0);
  }, [activeCustomers]);

  const filteredCustomers = useMemo(() => {
    return activeCustomers
      .filter((c) => {
        const q = searchQuery.trim().toLowerCase();
        const matchesQuery = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q);

        let matchesFilter = true;
        if (filterType === 'WITH_CREDIT') matchesFilter = c.outstandingCredit > 0;
        if (filterType === 'ZERO_CREDIT') matchesFilter = c.outstandingCredit === 0;

        return matchesQuery && matchesFilter;
      })
      .sort((a, b) => b.outstandingCredit - a.outstandingCredit);
  }, [activeCustomers, searchQuery, filterType]);

  const handleSendReminder = (customer: Customer) => {
    const formattedAmount = formatCurrency(customer.outstandingCredit, business.currency, lang);
    const message = t('reminderMessageTemplate', lang, {
      name: customer.name,
      business: business.name,
      amount: formattedAmount,
      currency: business.currency,
    });

    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`"${name}" පාරිභෝගිකයා මකා දැමීමට ඔබට විශ්වාසද?`)) {
      deleteCustomer(id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 pb-24 space-y-4">
      {/* Header Banner with Total Outstanding Credit */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-5 rounded-2xl border border-slate-700/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-teal-400" />
            <h2 className="text-lg sm:text-xl font-bold tracking-tight">{t('customersTitle', lang)}</h2>
            <span className="text-xs font-bold px-2 py-0.5 bg-slate-800 text-teal-300 rounded-full border border-slate-700">
              {activeCustomers.length}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            පාරිභෝගික ලැයිස්තුව, ණය ශේෂයන් සහ ගෙවීම් වාර්තා
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-2.5 px-3.5 text-right">
            <span className="text-[10px] text-slate-400 block font-semibold">
              {t('outstandingCredit', lang)}
            </span>
            <span className="font-extrabold text-base sm:text-lg text-amber-400">
              {formatCurrency(totalOutstandingCredit, business.currency, lang)}
            </span>
          </div>

          <button
            id="add-customer-main-btn"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-teal-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addCustomerTitle', lang)}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search', lang) + ' (නම, දුරකථන අංකය...)'}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="flex bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 text-xs">
          {[
            { id: 'ALL', label: t('all', lang) },
            { id: 'WITH_CREDIT', label: 'ණය ඇති අය (Due)' },
            { id: 'ZERO_CREDIT', label: 'ණය නැති අය (Clear)' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setFilterType(item.id as any)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                filterType === item.id
                  ? 'bg-teal-600 text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Cards List */}
      {filteredCustomers.length === 0 ? (
        <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 p-12 text-center">
          <Users className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('noCustomers', lang)}</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">{t('noCustomersDesc', lang)}</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="mt-4 px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addCustomerTitle', lang)}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredCustomers.map((customer) => {
            const hasCredit = customer.outstandingCredit > 0;

            return (
              <div
                key={customer.id}
                className={`bg-white dark:bg-slate-800/90 rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                  hasCredit
                    ? 'border-amber-300 dark:border-amber-900/60 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700/80'
                }`}
              >
                <div>
                  {/* Top Customer Info */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h4
                        onClick={() => setDetailCustomer(customer)}
                        className="font-bold text-sm text-slate-900 dark:text-slate-100 hover:text-teal-600 cursor-pointer truncate"
                      >
                        {customer.name}
                      </h4>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5 font-mono">
                        <Phone className="w-3 h-3 text-teal-600" />
                        <span>{customer.phone || 'දුරකථන අංකයක් නැත'}</span>
                      </p>
                    </div>

                    {/* Credit Status Badge */}
                    {hasCredit ? (
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 shrink-0">
                        ණය ඇත
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shrink-0">
                        පිරිසිදුයි
                      </span>
                    )}
                  </div>

                  {/* Financial Stats Grid */}
                  <div className="grid grid-cols-2 gap-2 my-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-750 border border-slate-100 dark:border-slate-700/60 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-500 block">{t('totalPurchases', lang)}</span>
                      <span className="font-bold text-slate-900 dark:text-slate-100">
                        {formatCurrency(customer.totalPurchases, business.currency, lang)}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 block">{t('dueCredit', lang)}</span>
                      <span
                        className={`font-black text-sm ${
                          hasCredit ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400'
                        }`}
                      >
                        {formatCurrency(customer.outstandingCredit, business.currency, lang)}
                      </span>
                    </div>
                  </div>

                  {customer.notes && (
                    <p className="text-[11px] text-slate-400 italic line-clamp-1 mb-2">
                      "{customer.notes}"
                    </p>
                  )}
                </div>

                {/* Card Action Controls */}
                <div className="pt-2.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between gap-1">
                  {/* Record Payment Button */}
                  {hasCredit ? (
                    <button
                      type="button"
                      onClick={() => setPaymentCustomer(customer)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs transition-colors"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>{t('recordPayment', lang)}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setDetailCustomer(customer)}
                      className="px-3 py-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>විස්තර බලන්න</span>
                    </button>
                  )}

                  {/* Communication & Edit Controls */}
                  <div className="flex items-center gap-1">
                    {customer.phone && (
                      <>
                        <a
                          href={`tel:${customer.phone}`}
                          className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg"
                          title="Call Customer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                        {hasCredit && (
                          <button
                            type="button"
                            onClick={() => handleSendReminder(customer)}
                            className="p-1.5 text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/60 rounded-lg"
                            title="Send WhatsApp Reminder"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </>
                    )}

                    <button
                      type="button"
                      onClick={() => setEditingCustomer(customer)}
                      className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
                      title={t('edit', lang)}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(customer.id, customer.name)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                      title={t('delete', lang)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modals */}
      {isAddModalOpen && (
        <AddEditCustomerModal
          onClose={() => setIsAddModalOpen(false)}
        />
      )}

      {editingCustomer && (
        <AddEditCustomerModal
          customerToEdit={editingCustomer}
          onClose={() => setEditingCustomer(null)}
        />
      )}

      {paymentCustomer && (
        <RecordPaymentModal
          customer={paymentCustomer}
          onClose={() => setPaymentCustomer(null)}
        />
      )}

      {detailCustomer && (
        <CustomerDetailModal
          customer={detailCustomer}
          onClose={() => setDetailCustomer(null)}
          onRecordPayment={() => {
            const c = detailCustomer;
            setDetailCustomer(null);
            setPaymentCustomer(c);
          }}
        />
      )}
    </div>
  );
};
