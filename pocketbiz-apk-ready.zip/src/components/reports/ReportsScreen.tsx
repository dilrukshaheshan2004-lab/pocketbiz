import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  Package,
  AlertTriangle,
  Receipt,
  FileSpreadsheet,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  CartesianGrid,
} from 'recharts';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { storage } from '../../utils/storage';
import { jsPDF } from 'jspdf';

export const ReportsScreen: React.FC = () => {
  const { sales, expenses, products, customers, business, lang } = useApp();

  const [timeRange, setTimeRange] = useState<'today' | '7days' | '30days' | 'thisMonth' | 'all'>('30days');

  // Filter datasets based on timeRange
  const { filteredSales, filteredExpenses, reportDates } = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const thisMonthStr = todayStr.substring(0, 7);

    const validSales = sales.filter((s) => !s.isVoided);
    const validExpenses = expenses.filter((e) => !e.isDeleted);

    let sList = validSales;
    let eList = validExpenses;

    if (timeRange === 'today') {
      sList = validSales.filter((s) => s.createdAt.startsWith(todayStr));
      eList = validExpenses.filter((e) => e.date.startsWith(todayStr));
    } else if (timeRange === '7days') {
      const past7 = new Date(Date.now() - 7 * 86400000);
      sList = validSales.filter((s) => new Date(s.createdAt) >= past7);
      eList = validExpenses.filter((e) => new Date(e.date) >= past7);
    } else if (timeRange === '30days') {
      const past30 = new Date(Date.now() - 30 * 86400000);
      sList = validSales.filter((s) => new Date(s.createdAt) >= past30);
      eList = validExpenses.filter((e) => new Date(e.date) >= past30);
    } else if (timeRange === 'thisMonth') {
      sList = validSales.filter((s) => s.createdAt.startsWith(thisMonthStr));
      eList = validExpenses.filter((e) => e.date.startsWith(thisMonthStr));
    }

    return { filteredSales: sList, filteredExpenses: eList, reportDates: { start: todayStr, end: todayStr } };
  }, [sales, expenses, timeRange]);

  // Aggregate metrics
  const totalSalesRevenue = useMemo(() => filteredSales.reduce((a, s) => a + s.totalAmount, 0), [filteredSales]);
  const totalCOGS = useMemo(() => filteredSales.reduce((a, s) => a + s.costTotal, 0), [filteredSales]);
  const grossProfit = totalSalesRevenue - totalCOGS;
  const totalExpenseAmount = useMemo(() => filteredExpenses.reduce((a, e) => a + e.amount, 0), [filteredExpenses]);
  const netProfit = grossProfit - totalExpenseAmount;
  const salesCount = filteredSales.length;
  const averageTicket = salesCount > 0 ? totalSalesRevenue / salesCount : 0;
  const outstandingCredit = useMemo(() => customers.filter((c) => !c.isDeleted).reduce((a, c) => a + c.outstandingCredit, 0), [customers]);

  // Daily Chart Aggregation (Last 7-14 points)
  const chartData = useMemo(() => {
    const map: Record<string, { date: string; sales: number; expenses: number; profit: number }> = {};

    // Group sales
    filteredSales.forEach((s) => {
      const d = s.createdAt.split('T')[0].substring(5); // MM-DD
      if (!map[d]) map[d] = { date: d, sales: 0, expenses: 0, profit: 0 };
      map[d].sales += s.totalAmount;
      map[d].profit += s.profit;
    });

    // Group expenses
    filteredExpenses.forEach((e) => {
      const d = e.date.split('T')[0].substring(5);
      if (!map[d]) map[d] = { date: d, sales: 0, expenses: 0, profit: 0 };
      map[d].expenses += e.amount;
      map[d].profit -= e.amount;
    });

    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
  }, [filteredSales, filteredExpenses]);

  // Top Selling Products
  const topProducts = useMemo(() => {
    const prodMap: Record<string, { name: string; quantity: number; revenue: number; profit: number }> = {};
    filteredSales.forEach((s) => {
      s.items.forEach((item) => {
        if (!prodMap[item.productId]) {
          prodMap[item.productId] = { name: item.productName, quantity: 0, revenue: 0, profit: 0 };
        }
        prodMap[item.productId].quantity += item.quantity;
        prodMap[item.productId].revenue += item.subtotal;
        prodMap[item.productId].profit += item.profit;
      });
    });
    return Object.values(prodMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  }, [filteredSales]);

  // Export Financial Summary PDF
  const handleExportPdfReport = () => {
    const doc = new jsPDF();
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.text(business.name, 14, 20);

    doc.setFontSize(12);
    doc.setTextColor(71, 85, 105);
    doc.text(`Financial Performance Report (${timeRange.toUpperCase()})`, 14, 28);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 34);

    doc.setDrawColor(200);
    doc.line(14, 38, 196, 38);

    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);

    let y = 48;
    const addRow = (label: string, value: string, isBold = false) => {
      doc.setFont('helvetica', isBold ? 'bold' : 'normal');
      doc.text(label, 14, y);
      doc.text(value, 196, y, { align: 'right' });
      y += 8;
    };

    addRow('Total Gross Sales Revenue:', formatCurrency(totalSalesRevenue, business.currency, 'en'));
    addRow('Cost of Goods Sold (COGS):', `-${formatCurrency(totalCOGS, business.currency, 'en')}`);
    addRow('Gross Profit:', formatCurrency(grossProfit, business.currency, 'en'), true);
    addRow('Total Operational Expenses:', `-${formatCurrency(totalExpenseAmount, business.currency, 'en')}`);
    doc.line(14, y, 196, y);
    y += 6;
    addRow('NET PROFIT:', formatCurrency(netProfit, business.currency, 'en'), true);
    addRow('Total Invoices Count:', String(salesCount));
    addRow('Average Ticket Size:', formatCurrency(averageTicket, business.currency, 'en'));
    addRow('Total Outstanding Credit Due:', formatCurrency(outstandingCredit, business.currency, 'en'));

    doc.save(`PocketBiz_Report_${timeRange}_${Date.now()}.pdf`);
  };

  const handleExportCsv = () => {
    const csv = storage.exportCsv('sales');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `pocketbiz_sales_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 pb-24 space-y-5">
      {/* Top Header & Time Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>{t('reportsTitle', lang)}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ව්‍යාපාර ලාභය, ආදායම් සහ වියදම් විශ්ලේෂණය
          </p>
        </div>

        {/* Time Filter Tabs */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 dark:bg-slate-750 p-1 rounded-xl text-xs">
          {[
            { id: 'today', label: t('timeToday', lang) },
            { id: '7days', label: t('time7Days', lang) },
            { id: '30days', label: t('time30Days', lang) },
            { id: 'thisMonth', label: t('timeThisMonth', lang) },
            { id: 'all', label: t('timeAll', lang) },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setTimeRange(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                timeRange === tab.id
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Gross Sales */}
        <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 block">{t('grossSales', lang)}</span>
          <span className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100 block mt-1">
            {formatCurrency(totalSalesRevenue, business.currency, lang)}
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">{salesCount} විකුණුම් බිල්පත්</span>
        </div>

        {/* Cost of Goods Sold (COGS) */}
        <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 block">{t('costOfGoods', lang)}</span>
          <span className="text-lg sm:text-xl font-black text-slate-700 dark:text-slate-300 block mt-1">
            {formatCurrency(totalCOGS, business.currency, lang)}
          </span>
          <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">
            දළ ලාභය: {formatCurrency(grossProfit, business.currency, lang)}
          </span>
        </div>

        {/* Expenses */}
        <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 block">{t('totalExpenses', lang)}</span>
          <span className="text-lg sm:text-xl font-black text-rose-600 dark:text-rose-400 block mt-1">
            {formatCurrency(totalExpenseAmount, business.currency, lang)}
          </span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">{filteredExpenses.length} වියදම් සටහන්</span>
        </div>

        {/* Net Profit */}
        <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs bg-gradient-to-br from-emerald-50/50 to-white dark:from-emerald-950/20 dark:to-slate-800">
          <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 block">
            {t('netProfit', lang)} (ශුද්ධ ලාභය)
          </span>
          <span
            className={`text-xl sm:text-2xl font-black block mt-1 ${
              netProfit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600'
            }`}
          >
            {formatCurrency(netProfit, business.currency, lang)}
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            ලාභ ප්‍රතිශතය: {totalSalesRevenue > 0 ? ((netProfit / totalSalesRevenue) * 100).toFixed(1) : 0}%
          </span>
        </div>
      </div>

      {/* Performance Chart */}
      <div className="bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-teal-600" />
            <span>විකුණුම් සහ ලාභ ප්‍රවණතාවය (Trends)</span>
          </h3>
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-teal-500" />
              <span className="text-slate-600 dark:text-slate-300">Sales</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-slate-600 dark:text-slate-300">Profit</span>
            </div>
          </div>
        </div>

        {chartData.length === 0 ? (
          <div className="h-48 flex items-center justify-center text-slate-400 text-xs">
            තෝරාගත් කාල සීමාව සඳහා ප්‍රමාණවත් දත්ත නොමැත.
          </div>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(val: any) => formatCurrency(Number(val), business.currency, lang)}
                  contentStyle={{ borderRadius: 12, backgroundColor: '#0f172a', color: '#fff', border: 'none' }}
                />
                <Area type="monotone" dataKey="sales" name="Sales" stroke="#0d9488" strokeWidth={2} fillOpacity={1} fill="url(#colorSales)" />
                <Area type="monotone" dataKey="profit" name="Profit" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorProfit)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Top Products Table & Export Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Top Products */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
          <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 mb-3">
            {t('topSelling', lang)}
          </h3>

          {topProducts.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-xs">
              දත්ත හමුනොවීය.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {topProducts.map((p, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-slate-100 truncate">{p.name}</span>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <span className="text-slate-500">{p.quantity} විකිණී ඇත</span>
                    <span className="font-extrabold text-slate-900 dark:text-slate-100 min-w-[70px] text-right">
                      {formatCurrency(p.revenue, business.currency, lang)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Report Export Buttons */}
        <div className="bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 mb-1">
              වාර්තා බාගත කිරීම් (Export)
            </h3>
            <p className="text-xs text-slate-500">
              ඔබේ ගිණුම් කටයුතු හෝ මුද්‍රණය සඳහා සම්පූර්ණ PDF සහ CSV වාර්තා ලබාගන්න.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={handleExportPdfReport}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>{t('exportReportPdf', lang)}</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="w-full py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>{t('exportCsv', lang)} (Sales CSV)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
