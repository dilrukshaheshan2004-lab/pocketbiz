import React, { useState } from 'react';
import { Lock, Delete, ShieldCheck, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export const PinLockScreen: React.FC = () => {
  const { unlockApp, lang, business } = useApp();
  const [pin, setPin] = useState('');
  const [hasError, setHasError] = useState(false);

  const handleDigit = (digit: string) => {
    if (pin.length >= 4) return;
    const newPin = pin + digit;
    setPin(newPin);
    setHasError(false);

    if (newPin.length === 4) {
      setTimeout(() => {
        const success = unlockApp(newPin);
        if (!success) {
          setHasError(true);
          setPin('');
        }
      }, 100);
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setHasError(false);
  };

  const handleClear = () => {
    setPin('');
    setHasError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col items-center justify-center p-6 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-xs flex flex-col items-center text-center">
        {/* App / Lock Icon */}
        <div className="w-16 h-16 rounded-2xl bg-teal-600/30 border border-teal-500/30 flex items-center justify-center text-teal-400 mb-4 shadow-lg shadow-teal-500/10">
          <Lock className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-bold text-slate-100">{business.name || 'PocketBiz'}</h2>
        <p className="text-xs text-slate-400 mt-1 mb-6">{t('enterPin', lang)}</p>

        {/* PIN Dots */}
        <div className="flex items-center justify-center gap-4 mb-6">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = index < pin.length;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-teal-400 scale-110 shadow-sm shadow-teal-400/50'
                    : 'bg-slate-700 border border-slate-600'
                } ${hasError ? 'bg-rose-500 animate-shake' : ''}`}
              />
            );
          })}
        </div>

        {/* Error message */}
        {hasError && (
          <div className="flex items-center gap-1.5 text-xs text-rose-400 mb-4 bg-rose-950/50 border border-rose-800/60 px-3 py-1.5 rounded-xl">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{t('wrongPin', lang)}</span>
          </div>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-4 w-full">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              id={`pin-key-${digit}`}
              onClick={() => handleDigit(digit)}
              className="h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 active:scale-95 text-2xl font-bold text-slate-100 flex items-center justify-center transition-all shadow-xs"
            >
              {digit}
            </button>
          ))}

          <button
            id="pin-key-clear"
            onClick={handleClear}
            className="h-16 rounded-2xl bg-slate-800/40 hover:bg-slate-800 border border-slate-700/40 active:scale-95 text-xs font-semibold text-slate-400 flex items-center justify-center transition-all"
          >
            Clear
          </button>

          <button
            id="pin-key-0"
            onClick={() => handleDigit('0')}
            className="h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 active:scale-95 text-2xl font-bold text-slate-100 flex items-center justify-center transition-all shadow-xs"
          >
            0
          </button>

          <button
            id="pin-key-delete"
            onClick={handleDelete}
            className="h-16 rounded-2xl bg-slate-800/40 hover:bg-slate-800 border border-slate-700/40 active:scale-95 text-slate-300 flex items-center justify-center transition-all"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>

        {/* Footer info */}
        <div className="mt-8 flex items-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
          <span>Offline Protected Security</span>
        </div>
      </div>
    </div>
  );
};
