import React from 'react';
import { Search, Lock, Globe, Moon, Sun, Store } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export const Header: React.FC = () => {
  const { business, settings, updateSettings, lang, setLang, setIsSearchOpen, lockApp } = useApp();

  const toggleTheme = () => {
    updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' });
  };

  const toggleLanguage = () => {
    setLang(lang === 'si' ? 'en' : 'si');
  };

  // Extract owner initials or store initials
  const initials = (business.name || 'PB')
    .split(' ')
    .map((word) => word[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  const ownerInitials = (business.ownerName || business.name || 'SS')
    .split(' ')
    .map((word) => word[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  const formattedDate = new Date().toLocaleDateString(lang === 'si' ? 'si-LK' : 'en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header className="bg-indigo-900 text-white px-4 sm:px-6 py-4 shadow-md transition-colors sticky top-0 z-30">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Brand / Business Info */}
        <div className="flex items-center space-x-3 min-w-0">
          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-indigo-900 font-bold text-lg shadow-sm shrink-0">
            {business.logoUrl ? (
              <span className="text-xl">{business.logoUrl}</span>
            ) : (
              initials || <Store className="w-5 h-5" />
            )}
          </div>
          <div className="min-w-0">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white truncate leading-tight">
              {business.name || 'PocketBiz'}
            </h1>
            <p className="text-xs text-indigo-200 truncate opacity-90">
              {t('tagline', lang)}
            </p>
          </div>
        </div>

        {/* Right: Date, Business name, Controls & User Avatar */}
        <div className="flex items-center space-x-2 sm:space-x-4 shrink-0">
          {/* Date & Store Name (Hidden on very small screens) */}
          <div className="text-right hidden md:block">
            <p className="text-xs opacity-75 text-indigo-200">{formattedDate}</p>
            <p className="text-sm font-semibold text-white truncate max-w-[140px]">
              {business.name || 'PocketBiz'}
            </p>
          </div>

          {/* Quick Search */}
          <button
            id="header-search-btn"
            onClick={() => setIsSearchOpen(true)}
            className="p-2 text-indigo-100 hover:text-white bg-indigo-800/70 hover:bg-indigo-700/80 rounded-xl transition-all border border-indigo-700/60"
            title={t('search', lang)}
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Language Switcher */}
          <button
            id="header-lang-btn"
            onClick={toggleLanguage}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-indigo-800/70 hover:bg-indigo-700/80 text-white rounded-xl text-xs font-bold border border-indigo-700/60 transition-all"
            title="Switch Language (සිංහල / English)"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'සිං' : 'EN'}</span>
          </button>

          {/* Theme Toggle */}
          <button
            id="header-theme-btn"
            onClick={toggleTheme}
            className="p-2 text-indigo-100 hover:text-white bg-indigo-800/70 hover:bg-indigo-700/80 rounded-xl transition-all border border-indigo-700/60"
            title={settings.theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
          >
            {settings.theme === 'dark' ? <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5" />}
          </button>

          {/* PIN Lock Trigger */}
          {settings.pinEnabled && settings.pinHash && (
            <button
              id="header-lock-btn"
              onClick={lockApp}
              className="p-2 text-rose-300 hover:text-white bg-rose-900/60 hover:bg-rose-800/70 rounded-xl border border-rose-700/60 transition-all"
              title="Lock Application"
            >
              <Lock className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}

          {/* Avatar Badge */}
          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-indigo-700 rounded-full border-2 border-indigo-500 flex items-center justify-center text-xs sm:text-sm font-semibold text-white shrink-0 shadow-inner">
            {ownerInitials}
          </div>
        </div>
      </div>
    </header>
  );
};
