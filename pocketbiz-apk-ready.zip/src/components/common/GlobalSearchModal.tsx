import React, { useState, useMemo } from 'react';
import { Search, X, Package, Users, ShoppingBag, ReceiptText, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';

export const GlobalSearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, products, customers, sales, expenses, business, lang, setActiveTab } = useApp();
  const [query, setQuery] = useState('');

  const filteredResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return { products: [], customers: [], sales: [], expenses: [] };
    }

    const matchedProducts = products
      .filter((p) => !p.isDeleted && (p.name.toLowerCase().includes(q) || (p.nameSi && p.nameSi.toLowerCase().includes(q)) || p.sku.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)))
      .slice(0, 4);

    const matchedCustomers = customers
      .filter((c) => !c.isDeleted && (c.name.toLowerCase().includes(q) || c.phone.includes(q)))
      .slice(0, 4);

    const matchedSales = sales
      .filter((s) => !s.isVoided && (s.invoiceNumber.toLowerCase().includes(q) || s.customerName.toLowerCase().includes(q)))
      .slice(0, 4);

    const matchedExpenses = expenses
      .filter((e) => !e.isDeleted && (e.title.toLowerCase().includes(q) || e.category.toLowerCase().includes(q)))
      .slice(0, 4);

    return {
      products: matchedProducts,
      customers: matchedCustomers,
      sales: matchedSales,
      expenses: matchedExpenses,
    };
  }, [query, products, customers, sales, expenses]);

  if (!isSearchOpen) return null;

  const hasAnyResults =
    filteredResults.products.length > 0 ||
    filteredResults.customers.length > 0 ||
    filteredResults.sales.length > 0 ||
    filteredResults.expenses.length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 px-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="absolute inset-0"
        onClick={() => setIsSearchOpen(false)}
      />
      <div className="relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden z-10 max-h-[85vh] flex flex-col">
        {/* Search Header */}
        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('search', lang) + ' (භාණ්ඩ, පාරිභෝගිකයින්, බිල්පත්...)'}
            className="w-full bg-transparent text-sm sm:text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="text-xs font-semibold px-2 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-lg hover:bg-slate-200"
          >
            ESC
          </button>
        </div>

        {/* Results List */}
        <div className="overflow-y-auto p-4 space-y-4">
          {!query && (
            <div className="text-center py-8 text-slate-400 text-sm">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-40 text-teal-600" />
              <p>භාණ්ඩයේ නම, SKU, පාරිභෝගිකයාගේ නම හෝ Invoice අංකය ඇතුළත් කරන්න.</p>
            </div>
          )}

          {query && !hasAnyResults && (
            <div className="text-center py-8 text-slate-400 text-sm">
              <p>"{query}" සඳහා ප්‍රතිඵල හමුනොවීය.</p>
            </div>
          )}

          {/* Products Results */}
          {filteredResults.products.length > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                <span className="flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-teal-600" />
                  {t('navProducts', lang)}
                </span>
                <button
                  onClick={() => {
                    setIsSearchOpen(false);
                    setActiveTab('products');
                  }}
                  className="text-teal-600 hover:underline flex items-center gap-0.5"
                >
                  {t('viewAll', lang)} <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {filteredResults.products.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      setActiveTab('products');
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-teal-50 dark:hover:bg-teal-950/40 border border-slate-200 dark:border-slate-700/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <p className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100">
                        {p.nameSi || p.name}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        SKU: {p.sku} • {p.category} • තොග: {p.stockQuantity} {p.unit}
                      </p>
                    </div>
                    <span className="font-bold text-xs sm:text-sm text-teal-700 dark:text-teal-300">
                      {formatCurrency(p.sellingPrice, business.currency, lang)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Customers Results */}
          {filteredResults.customers.length > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                <span className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-600" />
                  {t('navCustomers', lang)}
                </span>
                <button
                  onClick={() => {
                    setIsSearchOpen(false);
                    setActiveTab('customers');
                  }}
                  className="text-teal-600 hover:underline flex items-center gap-0.5"
                >
                  {t('viewAll', lang)} <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {filteredResults.customers.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      setActiveTab('customers');
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50 dark:hover:bg-blue-950/40 border border-slate-200 dark:border-slate-700/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <p className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100">{c.name}</p>
                      <p className="text-[11px] text-slate-500">{c.phone}</p>
                    </div>
                    {c.outstandingCredit > 0 && (
                      <span className="font-bold text-xs text-rose-600 bg-rose-50 dark:bg-rose-950/50 px-2 py-0.5 rounded-full border border-rose-200 dark:border-rose-800">
                        ණය: {formatCurrency(c.outstandingCredit, business.currency, lang)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Sales Results */}
          {filteredResults.sales.length > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                <span className="flex items-center gap-1.5">
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-600" />
                  {t('navInvoices', lang)}
                </span>
                <button
                  onClick={() => {
                    setIsSearchOpen(false);
                    setActiveTab('invoices');
                  }}
                  className="text-teal-600 hover:underline flex items-center gap-0.5"
                >
                  {t('viewAll', lang)} <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {filteredResults.sales.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      setActiveTab('invoices');
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-amber-50 dark:hover:bg-amber-950/40 border border-slate-200 dark:border-slate-700/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <p className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100">{s.invoiceNumber}</p>
                      <p className="text-[11px] text-slate-500">{s.customerName} • {formatDate(s.createdAt, lang)}</p>
                    </div>
                    <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">
                      {formatCurrency(s.totalAmount, business.currency, lang)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Expenses Results */}
          {filteredResults.expenses.length > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                <span className="flex items-center gap-1.5">
                  <ReceiptText className="w-3.5 h-3.5 text-rose-600" />
                  {t('navExpenses', lang)}
                </span>
                <button
                  onClick={() => {
                    setIsSearchOpen(false);
                    setActiveTab('expenses');
                  }}
                  className="text-teal-600 hover:underline flex items-center gap-0.5"
                >
                  {t('viewAll', lang)} <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {filteredResults.expenses.map((e) => (
                  <div
                    key={e.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      setActiveTab('expenses');
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-slate-200 dark:border-slate-700/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <p className="font-semibold text-xs sm:text-sm text-slate-900 dark:text-slate-100">{e.title}</p>
                      <p className="text-[11px] text-slate-500">{e.category} • {formatDate(e.date, lang)}</p>
                    </div>
                    <span className="font-bold text-xs sm:text-sm text-rose-600">
                      -{formatCurrency(e.amount, business.currency, lang)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
