import React, { useState } from 'react';
import { Home, ShoppingBag, Package, Users, MoreHorizontal, ReceiptText, BarChart3, FileText, Settings as SettingsIcon, X, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { ActiveTab } from '../../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, lang, cart } = useApp();
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const cartTotalCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const moreItems: { id: ActiveTab; label: string; icon: React.ReactNode; desc: string; color: string }[] = [
    { id: 'expenses', label: t('navExpenses', lang), icon: <ReceiptText className="w-5 h-5" />, desc: 'වියදම් සටහන් කිරීම', color: 'bg-rose-500' },
    { id: 'reports', label: t('navReports', lang), icon: <BarChart3 className="w-5 h-5" />, desc: 'ලාභය සහ සංඛ්‍යාලේඛන', color: 'bg-blue-600' },
    { id: 'invoices', label: t('navInvoices', lang), icon: <FileText className="w-5 h-5" />, desc: 'ඉන්වොයිස් සහ බිල්පත්', color: 'bg-amber-500' },
    { id: 'settings', label: t('navSettings', lang), icon: <SettingsIcon className="w-5 h-5" />, desc: 'සැකසුම් සහ Backup', color: 'bg-indigo-600' },
  ];

  const isMoreActive = ['expenses', 'reports', 'invoices', 'settings'].includes(activeTab);

  const handleSelectMore = (tab: ActiveTab) => {
    setActiveTab(tab);
    setIsMoreOpen(false);
  };

  return (
    <>
      {/* More Menu Bottom Sheet / Drawer */}
      {isMoreOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="absolute inset-0"
            onClick={() => setIsMoreOpen(false)}
          />
          <div className="relative bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 p-5 shadow-2xl max-w-lg mx-auto w-full z-10">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">
                {t('navMore', lang)}
              </h3>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-4 pb-2">
              {moreItems.map((item) => (
                <button
                  key={item.id}
                  id={`more-menu-${item.id}`}
                  onClick={() => handleSelectMore(item.id)}
                  className={`flex items-start gap-3 p-3.5 rounded-2xl border text-left transition-all ${
                    activeTab === item.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-indigo-900 dark:text-indigo-200 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className={`p-2 rounded-xl text-white ${item.color} shadow-xs shrink-0`}>
                    {item.icon}
                  </div>
                  <div>
                    <p className="font-bold text-sm leading-snug">{item.label}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">{item.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Bottom Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-2 px-4 sm:px-12 shadow-lg transition-colors">
        <div className="max-w-md md:max-w-2xl mx-auto flex items-center justify-between">
          {/* Home */}
          <button
            id="bottom-nav-home"
            onClick={() => {
              setIsMoreOpen(false);
              setActiveTab('home');
            }}
            className={`flex flex-col items-center justify-center transition-all ${
              activeTab === 'home'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-400 opacity-60 hover:opacity-100 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <div className="text-xl mb-0.5">
              <Home className="w-5 h-5" />
            </div>
            <span className="text-[10px] sm:text-xs font-semibold">{t('navHome', lang)}</span>
          </button>

          {/* Products */}
          <button
            id="bottom-nav-products"
            onClick={() => {
              setIsMoreOpen(false);
              setActiveTab('products');
            }}
            className={`flex flex-col items-center justify-center transition-all ${
              activeTab === 'products'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-400 opacity-60 hover:opacity-100 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <div className="text-xl mb-0.5">
              <Package className="w-5 h-5" />
            </div>
            <span className="text-[10px] sm:text-xs font-semibold">{t('navProducts', lang)}</span>
          </button>

          {/* Floating Center Action: New Sale (POS) */}
          <button
            id="bottom-nav-floating-sale"
            onClick={() => {
              setIsMoreOpen(false);
              setActiveTab('sales');
            }}
            className="w-13 h-13 sm:w-14 sm:h-14 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded-full flex items-center justify-center shadow-lg -mt-6 border-4 border-white dark:border-slate-900 transition-all relative group"
            title="New Sale"
          >
            <ShoppingBag className="w-6 h-6 group-hover:scale-110 transition-transform" />
            {cartTotalCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shadow-md border-2 border-white dark:border-slate-900">
                {cartTotalCount > 99 ? '99+' : cartTotalCount}
              </span>
            )}
          </button>

          {/* Customers */}
          <button
            id="bottom-nav-customers"
            onClick={() => {
              setIsMoreOpen(false);
              setActiveTab('customers');
            }}
            className={`flex flex-col items-center justify-center transition-all ${
              activeTab === 'customers'
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-400 opacity-60 hover:opacity-100 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <div className="text-xl mb-0.5">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-[10px] sm:text-xs font-semibold">{t('navCustomers', lang)}</span>
          </button>

          {/* More Trigger */}
          <button
            id="bottom-nav-more"
            onClick={() => setIsMoreOpen(!isMoreOpen)}
            className={`flex flex-col items-center justify-center transition-all ${
              isMoreActive
                ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                : 'text-slate-400 opacity-60 hover:opacity-100 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <div className="text-xl mb-0.5">
              <MoreHorizontal className="w-5 h-5" />
            </div>
            <span className="text-[10px] sm:text-xs font-semibold">{t('navMore', lang)}</span>
          </button>
        </div>
      </nav>
    </>
  );
};
