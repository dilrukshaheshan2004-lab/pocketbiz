import React, { useState } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  Plus,
  ArrowRight,
  Package,
  Eye,
  Calendar,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Sale, Product } from '../../types';
import { ReceiptModal } from '../modals/ReceiptModal';
import { AddEditProductModal } from '../modals/AddEditProductModal';
import { AddEditExpenseModal } from '../modals/AddEditExpenseModal';
import { AddEditCustomerModal } from '../modals/AddEditCustomerModal';
import { StockAdjustModal } from '../modals/StockAdjustModal';

export const HomeDashboard: React.FC = () => {
  const { business, metrics, lang, setActiveTab } = useApp();

  // Modals state
  const [selectedSaleForReceipt, setSelectedSaleForReceipt] = useState<Sale | null>(null);
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [restockProduct, setRestockProduct] = useState<Product | null>(null);

  // Greeting
  const greetingText =
    lang === 'si'
      ? `ආයුබෝවන්, ${business.ownerName || business.name || 'සන්තුෂ්'}!`
      : `Welcome, ${business.ownerName || business.name || 'Merchant'}!`;

  const greetingSubtitle =
    lang === 'si'
      ? 'මෙන්න අද දවසේ ඔබේ ව්‍යාපාරයේ තත්ත්වය.'
      : "Here is today's overview of your business.";

  return (
    <div className="space-y-6 pb-24 max-w-7xl mx-auto px-4 sm:px-6 pt-5 font-sans">
      {/* Salutation Header Banner */}
      <div className="bg-indigo-900 text-white p-5 sm:p-6 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-200 text-xs font-semibold mb-1">
            <Calendar className="w-3.5 h-3.5" />
            <span>
              {new Date().toLocaleDateString(lang === 'si' ? 'si-LK' : 'en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">{greetingText}</h2>
          <p className="text-indigo-200 text-xs sm:text-sm mt-1">{greetingSubtitle}</p>
        </div>

        {/* Quick New Sale button */}
        <button
          id="dash-quick-sale-hero-btn"
          onClick={() => setActiveTab('sales')}
          className="self-start sm:self-auto flex items-center gap-2 px-5 py-2.5 bg-white text-indigo-900 hover:bg-indigo-50 font-bold rounded-xl shadow-sm text-sm transition-all active:scale-95"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>{t('addSale', lang)}</span>
        </button>
      </div>

      {/* Main Grid: Left 8 Cols (Summary & Actions), Right 4 Cols (Low Stock & Recent Sales) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
        {/* Left Column (8 cols on large screens) */}
        <div className="lg:col-span-8 space-y-6 lg:space-y-8">
          {/* Section: Today Summary */}
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4 flex items-center justify-between">
              <span>{lang === 'si' ? 'අද සාරාංශය / Today Summary' : 'Today Summary'}</span>
              <span className="text-xs normal-case font-medium text-slate-400">
                {metrics.todaySalesCount} {lang === 'si' ? 'බිල්පත්' : 'invoices'}
              </span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* 1. Today Sales */}
              <div
                onClick={() => setActiveTab('invoices')}
                className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-200 dark:hover:border-indigo-800 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 p-2 rounded-lg text-lg">
                    💰
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 text-xs font-bold">
                    {metrics.todaySalesCount > 0 ? `+${metrics.todaySalesCount} Sales` : 'දෛනික අලෙවිය'}
                  </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-1">
                  {lang === 'si' ? 'අද විකුණුම් / Today Sales' : 'Today Sales'}
                </p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                  {formatCurrency(metrics.todaySales, business.currency, lang)}
                </p>
              </div>

              {/* 2. Today Expenses */}
              <div
                onClick={() => setActiveTab('expenses')}
                className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-200 dark:hover:border-indigo-800 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 p-2 rounded-lg text-lg">
                    💸
                  </span>
                  <span className="text-rose-600 dark:text-rose-400 text-xs font-bold">
                    දෛනික වියදම්
                  </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-1">
                  {lang === 'si' ? 'අද වියදම් / Today Expenses' : 'Today Expenses'}
                </p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                  {formatCurrency(metrics.todayExpenses, business.currency, lang)}
                </p>
              </div>

              {/* 3. Today Profit */}
              <div
                onClick={() => setActiveTab('reports')}
                className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-200 dark:hover:border-indigo-800 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 p-2 rounded-lg text-lg">
                    📈
                  </span>
                  <span className="text-blue-600 dark:text-blue-400 text-xs font-bold flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" /> {metrics.todayNetProfit >= 0 ? 'ලාභදායී' : 'අලාභ'}
                  </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-1">
                  {lang === 'si' ? 'අද ලාභය / Today Profit' : 'Today Net Profit'}
                </p>
                <p
                  className={`text-2xl sm:text-3xl font-bold tracking-tight ${
                    metrics.todayNetProfit >= 0 ? 'text-slate-800 dark:text-slate-100' : 'text-rose-600'
                  }`}
                >
                  {formatCurrency(metrics.todayNetProfit, business.currency, lang)}
                </p>
              </div>

              {/* 4. Outstanding Credit */}
              <div
                onClick={() => setActiveTab('customers')}
                className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-200 dark:hover:border-indigo-800 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 p-2 rounded-lg text-lg">
                    💳
                  </span>
                  <span className="text-amber-600 dark:text-amber-400 text-xs font-bold">
                    ගෙවීමට ඇති
                  </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-1">
                  {lang === 'si' ? 'ලැබිය යුතු / Credit Due' : 'Outstanding Credit'}
                </p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                  {formatCurrency(metrics.outstandingCredit, business.currency, lang)}
                </p>
              </div>
            </div>
          </section>

          {/* Section: Quick Actions */}
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4">
              {lang === 'si' ? 'ඉක්මන් ක්‍රියා / Quick Actions' : 'Quick Actions'}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <button
                id="dash-action-sale"
                onClick={() => setActiveTab('sales')}
                className="flex flex-col items-center justify-center p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-all active:scale-95 text-center"
              >
                <span className="text-2xl mb-2">🛍️</span>
                <span className="text-xs font-bold">{lang === 'si' ? 'විකිණීමක්' : 'New Sale'}</span>
              </button>

              <button
                id="dash-action-product"
                onClick={() => setIsAddProductOpen(true)}
                className="flex flex-col items-center justify-center p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-all active:scale-95 text-center"
              >
                <span className="text-2xl mb-2">📦</span>
                <span className="text-xs font-bold">{lang === 'si' ? 'භාණ්ඩයක්' : 'Product'}</span>
              </button>

              <button
                id="dash-action-expense"
                onClick={() => setIsAddExpenseOpen(true)}
                className="flex flex-col items-center justify-center p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-all active:scale-95 text-center"
              >
                <span className="text-2xl mb-2">📝</span>
                <span className="text-xs font-bold">{lang === 'si' ? 'වියදමක්' : 'Expense'}</span>
              </button>

              <button
                id="dash-action-customer"
                onClick={() => setIsAddCustomerOpen(true)}
                className="flex flex-col items-center justify-center p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-all active:scale-95 text-center"
              >
                <span className="text-2xl mb-2">👥</span>
                <span className="text-xs font-bold">{lang === 'si' ? 'පාරිභෝගික' : 'Customer'}</span>
              </button>
            </div>
          </section>
        </div>

        {/* Right Column (4 cols on large screens) */}
        <div className="lg:col-span-4 space-y-6 lg:space-y-8">
          {/* Low Stock Alert Section */}
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4 flex items-center justify-between">
              <span>{lang === 'si' ? 'අඩු Stock / Low Stock Alert' : 'Low Stock Alert'}</span>
              {metrics.lowStockCount > 0 && (
                <span className="text-xs font-bold px-2 py-0.5 bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 rounded-full">
                  {metrics.lowStockCount}
                </span>
              )}
            </h3>

            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-700 shadow-sm overflow-hidden">
              {metrics.lowStockProducts.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                  <Package className="w-8 h-8 mx-auto mb-2 text-emerald-500 opacity-60" />
                  <p>{lang === 'si' ? 'සියලුම භාණ්ඩ ප්‍රමාණවත් තොග ඇත.' : 'All stock levels are optimal.'}</p>
                </div>
              ) : (
                metrics.lowStockProducts.slice(0, 3).map((product) => (
                  <div key={product.id} className="p-4 flex justify-between items-center hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors">
                    <div className="min-w-0 pr-2">
                      <p className="font-medium text-sm text-slate-800 dark:text-slate-100 truncate">
                        {product.nameSi || product.name}
                      </p>
                      <p className="text-xs text-rose-500 font-semibold mt-0.5">
                        {lang === 'si'
                          ? `ඉතිරිව ඇත්තේ ${product.stockQuantity}${product.unit} පමණයි`
                          : `Only ${product.stockQuantity} ${product.unit} remaining`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded text-slate-500 dark:text-slate-400 font-mono">
                        {product.sku ? `REF: ${product.sku}` : `MIN: ${product.lowStockLimit}`}
                      </span>
                      <button
                        onClick={() => setRestockProduct(product)}
                        className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors"
                        title="Restock"
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))
              )}

              <div className="p-3 text-center bg-slate-50/50 dark:bg-slate-800/50">
                <button
                  onClick={() => setActiveTab('products')}
                  className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 text-xs font-bold uppercase tracking-widest"
                >
                  {lang === 'si' ? 'සියල්ල බලන්න' : 'View All Products'}
                </button>
              </div>
            </div>
          </section>

          {/* Recent Sales Section */}
          <section>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4 flex items-center justify-between">
              <span>{lang === 'si' ? 'මෑතකදී කළ විකිණුම් / Recent Sales' : 'Recent Sales'}</span>
              <button
                onClick={() => setActiveTab('invoices')}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 normal-case"
              >
                {t('viewAll', lang)} <ArrowRight className="w-3 h-3" />
              </button>
            </h3>

            {metrics.recentSales.length === 0 ? (
              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 text-center text-xs text-slate-400 shadow-sm">
                <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-indigo-600 opacity-40" />
                <p>{t('noRecentSales', lang)}</p>
                <button
                  onClick={() => setActiveTab('sales')}
                  className="mt-3 text-xs font-bold px-3 py-1.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-500 inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('addSale', lang)}</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {metrics.recentSales.slice(0, 4).map((sale) => {
                  const isCredit = sale.paymentMethod === 'CREDIT';
                  return (
                    <div
                      key={sale.id}
                      className={`flex items-center p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-300 dark:hover:border-indigo-700 transition-all ${
                        isCredit ? 'border-l-4 border-l-amber-400' : ''
                      }`}
                    >
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl mr-3 shrink-0 ${
                          isCredit
                            ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-600'
                            : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600'
                        }`}
                      >
                        {isCredit ? '💳' : '🛒'}
                      </div>
                      <div className="flex-1 min-w-0 pr-2">
                        <p className={`text-sm font-bold truncate ${isCredit ? 'text-amber-800 dark:text-amber-300' : 'text-slate-900 dark:text-slate-100'}`}>
                          {sale.invoiceNumber} {isCredit ? '(Credit)' : ''}
                        </p>
                        <p className="text-xs text-slate-400 dark:text-slate-400 truncate">
                          {formatDate(sale.createdAt, lang)} • {sale.paymentMethod}
                        </p>
                      </div>
                      <div className="text-right shrink-0 flex items-center gap-2">
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-100">
                          {formatCurrency(sale.totalAmount, business.currency, lang)}
                        </p>
                        <button
                          onClick={() => setSelectedSaleForReceipt(sale)}
                          className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded transition-colors"
                          title="View"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Modals */}
      {selectedSaleForReceipt && (
        <ReceiptModal
          sale={selectedSaleForReceipt}
          onClose={() => setSelectedSaleForReceipt(null)}
        />
      )}

      {isAddProductOpen && (
        <AddEditProductModal
          onClose={() => setIsAddProductOpen(false)}
        />
      )}

      {isAddExpenseOpen && (
        <AddEditExpenseModal
          onClose={() => setIsAddExpenseOpen(false)}
        />
      )}

      {isAddCustomerOpen && (
        <AddEditCustomerModal
          onClose={() => setIsAddCustomerOpen(false)}
        />
      )}

      {restockProduct && (
        <StockAdjustModal
          product={restockProduct}
          onClose={() => setRestockProduct(null)}
        />
      )}
    </div>
  );
};
