import React, { useState } from 'react';
import { X, Package, Sparkles, CheckCircle2, Tag, DollarSign, Layers } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { Product } from '../../types';

interface AddEditProductModalProps {
  productToEdit?: Product;
  onClose: () => void;
}

export const AddEditProductModal: React.FC<AddEditProductModalProps> = ({ productToEdit, onClose }) => {
  const { addProduct, updateProduct, categories, addCategory, lang, business } = useApp();

  const [name, setName] = useState(productToEdit?.name || '');
  const [nameSi, setNameSi] = useState(productToEdit?.nameSi || '');
  const [sku, setSku] = useState(productToEdit?.sku || `SKU-${Math.floor(1000 + Math.random() * 9000)}`);
  const [category, setCategory] = useState(productToEdit?.category || (categories[0]?.name || 'General'));
  const [sellingPrice, setSellingPrice] = useState(productToEdit ? String(productToEdit.sellingPrice) : '');
  const [costPrice, setCostPrice] = useState(productToEdit ? String(productToEdit.costPrice) : '');
  const [stockQuantity, setStockQuantity] = useState(productToEdit ? String(productToEdit.stockQuantity) : '10');
  const [lowStockLimit, setLowStockLimit] = useState(productToEdit ? String(productToEdit.lowStockLimit) : '5');
  const [unit, setUnit] = useState(productToEdit?.unit || 'pcs');
  const [imageUrl, setImageUrl] = useState(productToEdit?.imageUrl || '📦');

  const emojiPresets = ['📦', '🍞', '🥛', '🍚', '☕', '🧼', '🧴', '🥫', '🍫', '🧃', '🍗', '🌾', '👕', '📱', '🔋', '🔧', '💊', '📚', '🪑', '🪴'];
  const unitOptions = ['pcs', 'kg', 'packet', 'bottle', 'box', 'litre', 'metre', 'g'];

  const handleGenerateSku = () => {
    setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const sPrice = parseFloat(sellingPrice) || 0;
    const cPrice = parseFloat(costPrice) || 0;
    const stock = parseFloat(stockQuantity) || 0;
    const lowLimit = parseFloat(lowStockLimit) || 5;

    if (productToEdit) {
      updateProduct({
        ...productToEdit,
        name: name.trim(),
        nameSi: nameSi.trim() || undefined,
        sku: sku.trim(),
        category,
        sellingPrice: sPrice,
        costPrice: cPrice,
        stockQuantity: stock,
        lowStockLimit: lowLimit,
        unit,
        imageUrl,
      });
    } else {
      addProduct({
        name: name.trim(),
        nameSi: nameSi.trim() || undefined,
        sku: sku.trim(),
        category,
        sellingPrice: sPrice,
        costPrice: cPrice,
        stockQuantity: stock,
        lowStockLimit: lowLimit,
        unit,
        imageUrl,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden max-h-[95vh] flex flex-col z-10">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center text-sm font-bold">
              <Package className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100">
              {productToEdit ? t('editProduct', lang) : t('addProductTitle', lang)}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Product Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('productName', lang)} (English) *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Anchor Milk Powder 400g"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                භාණ්ඩයේ නම (සිංහල)
              </label>
              <input
                type="text"
                value={nameSi}
                onChange={(e) => setNameSi(e.target.value)}
                placeholder="උදා: ඇන්කර් කිරිපිටි 400g"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* SKU & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {t('sku', lang)} *
                </label>
                <button
                  type="button"
                  onClick={handleGenerateSku}
                  className="text-[10px] text-teal-600 dark:text-teal-400 font-bold hover:underline"
                >
                  Auto Generate
                </button>
              </div>
              <input
                type="text"
                required
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('category', lang)} *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {lang === 'si' && c.nameSi ? c.nameSi : c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Prices */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('sellingPrice', lang)} ({business.currency}) *
              </label>
              <input
                type="number"
                step="0.01"
                required
                min="0"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm font-bold text-teal-700 dark:text-teal-300 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('costPrice', lang)} ({business.currency}) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Stock & Units */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('stockQuantity', lang)} *
              </label>
              <input
                type="number"
                min="0"
                required
                value={stockQuantity}
                onChange={(e) => setStockQuantity(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('unit', lang)}
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-2 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
              >
                {unitOptions.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('lowStockLimit', lang)}
              </label>
              <input
                type="number"
                min="1"
                value={lowStockLimit}
                onChange={(e) => setLowStockLimit(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
              />
            </div>
          </div>

          {/* Emoji Icon Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              භාණ්ඩ Icon (Emoji)
            </label>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {emojiPresets.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setImageUrl(emoji)}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 border transition-all ${
                    imageUrl === emoji
                      ? 'bg-teal-100 dark:bg-teal-950 border-teal-500 scale-110 shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
            >
              {t('cancel', lang)}
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{productToEdit ? t('save', lang) : t('addProductTitle', lang)}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
