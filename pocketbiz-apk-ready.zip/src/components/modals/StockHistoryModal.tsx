import React, { useState } from 'react';
import { X, History, Search, ArrowDownRight, ArrowUpRight, RefreshCw, Filter } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatDate } from '../../utils/formatters';

interface StockHistoryModalProps {
  onClose: () => void;
}

export const StockHistoryModal: React.FC<StockHistoryModalProps> = ({ onClose }) => {
  const { stockMovements, products, lang } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMovements = stockMovements.filter((m) => {
    const q = searchQuery.trim().toLowerCase();
    return !q || m.productName.toLowerCase().includes(q) || (m.reason && m.reason.toLowerCase().includes(q));
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden max-h-[90vh] flex flex-col z-10">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-teal-600" />
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100">
              {t('movementHistory', lang)} ({stockMovements.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-slate-100 dark:border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="භාණ්ඩයේ නම අනුව සොයන්න..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>
        </div>

        {/* Movement Logs List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 divide-y divide-slate-100 dark:divide-slate-800">
          {filteredMovements.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              තොග චලන වාර්තා නොමැත.
            </div>
          ) : (
            filteredMovements.map((m) => {
              const isPositive = m.quantity > 0 && (m.type === 'RESTOCK' || m.type === 'PURCHASE' || m.type === 'INITIAL');

              return (
                <div key={m.id} className="pt-2 flex items-center justify-between text-xs">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-slate-100 truncate">
                        {m.productName}
                      </span>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                          m.type === 'SALE'
                            ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                            : m.type === 'RESTOCK' || m.type === 'PURCHASE'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {m.type}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {formatDate(m.createdAt, lang)} {m.reason ? `• ${m.reason}` : ''}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`font-black text-xs ${
                        isPositive ? 'text-emerald-600' : 'text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {isPositive ? `+${m.quantity}` : m.quantity}
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      {m.previousQuantity} → {m.newQuantity}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
