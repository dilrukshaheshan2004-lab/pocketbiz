import React from 'react';
import {
  X,
  User,
  Phone,
  MapPin,
  DollarSign,
  Send,
  ShoppingBag,
  History,
  Calendar,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Customer } from '../../types';

interface CustomerDetailModalProps {
  customer: Customer;
  onClose: () => void;
  onRecordPayment: () => void;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  onClose,
  onRecordPayment,
}) => {
  const { sales, payments, business, lang } = useApp();

  const customerSales = sales.filter((s) => s.customerId === customer.id && !s.isVoided);
  const customerPayments = payments.filter((p) => p.customerId === customer.id);

  const handleSendReminder = () => {
    const formattedAmount = formatCurrency(customer.outstandingCredit, business.currency, lang);
    const message = t('reminderMessageTemplate', lang, {
      name: customer.name,
      business: business.name,
      amount: formattedAmount,
      currency: business.currency,
    });

    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden max-h-[90vh] flex flex-col z-10">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center text-sm font-bold">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100">
                {customer.name}
              </h3>
              <p className="text-[11px] text-slate-500 font-mono">{customer.phone}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Credit & Purchase Summary Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800">
              <span className="text-[10px] font-bold text-amber-800 dark:text-amber-300 block">
                {t('outstandingCredit', lang)}
              </span>
              <span className="font-black text-base sm:text-lg text-amber-700 dark:text-amber-300 block mt-0.5">
                {formatCurrency(customer.outstandingCredit, business.currency, lang)}
              </span>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-slate-500 block">
                {t('totalPurchases', lang)}
              </span>
              <span className="font-black text-base sm:text-lg text-slate-900 dark:text-slate-100 block mt-0.5">
                {formatCurrency(customer.totalPurchases, business.currency, lang)}
              </span>
            </div>
          </div>

          {/* Quick Actions */}
          {customer.outstandingCredit > 0 && (
            <div className="flex gap-2">
              <button
                onClick={onRecordPayment}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
              >
                <DollarSign className="w-4 h-4" />
                <span>{t('recordPayment', lang)}</span>
              </button>

              {customer.phone && (
                <button
                  onClick={handleSendReminder}
                  className="px-4 py-2.5 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Send className="w-4 h-4" />
                  <span>WhatsApp මතක් කිරීම</span>
                </button>
              )}
            </div>
          )}

          {/* Sales History */}
          <div>
            <h4 className="font-bold text-xs text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
              <ShoppingBag className="w-3.5 h-3.5 text-teal-600" />
              <span>මිලදී ගැනීම් ඉතිහාසය ({customerSales.length})</span>
            </h4>
            {customerSales.length === 0 ? (
              <p className="text-xs text-slate-400">මිලදී ගැනීම් නොමැත.</p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {customerSales.map((s) => (
                  <div
                    key={s.id}
                    className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-slate-100 font-mono">
                        {s.invoiceNumber}
                      </span>
                      <span className="text-[10px] text-slate-500 block">{formatDate(s.createdAt, lang)}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-slate-900 dark:text-slate-100 block">
                        {formatCurrency(s.totalAmount, business.currency, lang)}
                      </span>
                      <span
                        className={`text-[9px] font-bold ${
                          s.paymentStatus === 'PAID' ? 'text-emerald-600' : 'text-amber-600'
                        }`}
                      >
                        {s.paymentStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Repayments History */}
          <div>
            <h4 className="font-bold text-xs text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-emerald-600" />
              <span>ණය පියවීම් ඉතිහාසය ({customerPayments.length})</span>
            </h4>
            {customerPayments.length === 0 ? (
              <p className="text-xs text-slate-400">ගෙවීම් සටහන් නොමැත.</p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {customerPayments.map((p) => (
                  <div
                    key={p.id}
                    className="p-2.5 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-xl border border-emerald-100 dark:border-emerald-900/40 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900 dark:text-slate-100">
                        {formatDate(p.createdAt, lang)}
                      </span>
                      <span className="text-[10px] text-slate-500 block">
                        {p.paymentMethod} {p.notes ? `• ${p.notes}` : ''}
                      </span>
                    </div>
                    <span className="font-extrabold text-emerald-700 dark:text-emerald-400">
                      +{formatCurrency(p.amount, business.currency, lang)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
