import React, { useState } from 'react';
import { X, SlidersHorizontal, Plus, Minus, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { Product, StockMovementType } from '../../types';

interface StockAdjustModalProps {
  product: Product;
  onClose: () => void;
}

export const StockAdjustModal: React.FC<StockAdjustModalProps> = ({ product, onClose }) => {
  const { adjustStock, lang } = useApp();

  const [type, setType] = useState<StockMovementType>('RESTOCK');
  const [quantity, setQuantity] = useState<string>('1');
  const [reason, setReason] = useState<string>('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = parseFloat(quantity);
    if (!qty || qty <= 0) return;

    adjustStock(product.id, type, qty, reason.trim() || undefined);
    onClose();
  };

  const calculatedNewStock = () => {
    const qty = parseFloat(quantity) || 0;
    if (type === 'RESTOCK' || type === 'PURCHASE') {
      return product.stockQuantity + qty;
    } else if (type === 'DAMAGE' || type === 'RETURN' || type === 'EXPIRED') {
      return Math.max(0, product.stockQuantity - qty);
    } else {
      // ADJUST (sets exact quantity)
      return qty;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden z-10">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-teal-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">
              {t('stockManagement', lang)}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4">
          {/* Product Summary */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">
                {product.nameSi || product.name}
              </h4>
              <p className="text-[11px] text-slate-500 font-mono">SKU: {product.sku}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">වත්මන් තොගය</span>
              <span className="font-black text-sm text-teal-600 dark:text-teal-400">
                {product.stockQuantity} {product.unit}
              </span>
            </div>
          </div>

          {/* Movement Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              ගැලපුම් වර්ගය (Adjustment Type)
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'RESTOCK', label: '+ තොග එකතු (Restock)', icon: <Plus className="w-3.5 h-3.5" /> },
                { id: 'DAMAGE', label: '- හානි/අපතේ (Damage)', icon: <Minus className="w-3.5 h-3.5" /> },
                { id: 'ADJUST', label: '= සංශෝධනය (Set Count)', icon: <RefreshCw className="w-3.5 h-3.5" /> },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setType(item.id as StockMovementType)}
                  className={`p-2 rounded-xl text-[11px] font-bold border transition-all flex flex-col items-center justify-center text-center gap-1 ${
                    type === item.id
                      ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quantity Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {type === 'ADJUST' ? 'නව තොග ප්‍රමාණය (New Quantity)' : 'වෙනස් වන ප්‍රමාණය (Quantity)'} ({product.unit}) *
            </label>
            <input
              type="number"
              step="any"
              min="0.1"
              required
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-sm font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Reason Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              හේතුව / සටහන (Reason / Note)
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="උදා: තොග ගණනය කිරීමේදී අඩු විය"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Preview Calculated Stock */}
          <div className="p-3 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-teal-200 dark:border-teal-800 flex items-center justify-between text-xs">
            <span className="font-semibold text-teal-900 dark:text-teal-200">ගැලපීමෙන් පසු නව තොගය:</span>
            <span className="font-extrabold text-sm text-teal-700 dark:text-teal-300">
              {calculatedNewStock()} {product.unit}
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
            >
              {t('cancel', lang)}
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('save', lang)}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
