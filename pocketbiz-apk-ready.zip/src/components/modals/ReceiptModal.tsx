import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  Share2,
  CheckCircle2,
  Store,
  Phone,
  Calendar,
  FileText,
  Copy,
  Receipt as ReceiptIcon,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Sale } from '../../types';
import { generateInvoicePdf, generateReceiptPdf } from '../../utils/pdfGenerator';

interface ReceiptModalProps {
  sale: Sale;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ sale, onClose }) => {
  const { business, lang, settings } = useApp();
  const [viewFormat, setViewFormat] = useState<'a4' | 'thermal'>('thermal');
  const [copied, setCopied] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    if (viewFormat === 'thermal') {
      generateReceiptPdf(sale, business, lang);
    } else {
      generateInvoicePdf(sale, business, lang);
    }
  };

  const handleShareWhatsApp = () => {
    const formattedAmount = formatCurrency(sale.totalAmount, business.currency, lang);
    let itemsText = sale.items
      .map((i) => `• ${i.productName} x ${i.quantity} = ${formatCurrency(i.subtotal, business.currency, lang)}`)
      .join('\n');

    const msg = `🧾 *${business.name}*\n` +
      `Invoice: *${sale.invoiceNumber}*\n` +
      `Date: ${formatDate(sale.createdAt, lang)}\n` +
      `Customer: ${sale.customerName}\n\n` +
      `*Items:*\n${itemsText}\n\n` +
      (sale.discountAmount > 0 ? `Discount: -${formatCurrency(sale.discountAmount, business.currency, lang)}\n` : '') +
      `*Total: ${formattedAmount}*\n` +
      `Payment: ${sale.paymentMethod} (${sale.paymentStatus})\n\n` +
      `${settings.invoiceFooterNote || 'Thank you for your business!'}`;

    const cleanPhone = sale.customerPhone ? sale.customerPhone.replace(/[^0-9]/g, '') : '';
    const url = cleanPhone
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleCopyText = () => {
    const formattedAmount = formatCurrency(sale.totalAmount, business.currency, lang);
    const text = `${business.name}\nInvoice: ${sale.invoiceNumber}\nTotal: ${formattedAmount}\nDate: ${formatDate(sale.createdAt, lang)}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden max-h-[95vh] flex flex-col z-10">
        {/* Top Actions Bar (Hidden during window.print) */}
        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850 print:hidden">
          {/* Format Toggle */}
          <div className="flex bg-slate-200 dark:bg-slate-700 p-0.5 rounded-xl text-xs">
            <button
              onClick={() => setViewFormat('thermal')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                viewFormat === 'thermal'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              80mm Thermal Slip
            </button>
            <button
              onClick={() => setViewFormat('a4')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                viewFormat === 'a4'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              A4 Invoice
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100 dark:bg-slate-950/60 flex justify-center">
          {/* Printable Ticket Container */}
          <div
            id="printable-receipt"
            className={`bg-white text-slate-900 p-6 shadow-md transition-all ${
              viewFormat === 'thermal'
                ? 'w-full max-w-[340px] rounded-2xl font-mono text-xs border border-dashed border-slate-300'
                : 'w-full max-w-md rounded-2xl font-sans text-sm border border-slate-200'
            }`}
          >
            {/* Store Header */}
            <div className="text-center pb-3 border-b border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white font-black text-base flex items-center justify-center mx-auto mb-1.5">
                {business.logoUrl || '🏪'}
              </div>
              <h3 className="font-extrabold text-base tracking-tight text-slate-900">{business.name}</h3>
              {business.address && <p className="text-[11px] text-slate-500">{business.address}</p>}
              {business.phone && <p className="text-[11px] text-slate-500">Tel: {business.phone}</p>}
            </div>

            {/* Invoice Meta */}
            <div className="py-2.5 border-b border-slate-200 text-[11px] space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">{t('invoiceNo', lang)}:</span>
                <span className="font-bold text-slate-900">{sale.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">{t('date', lang)}:</span>
                <span>{formatDate(sale.createdAt, lang)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-semibold">{t('customer', lang)}:</span>
                <span className="font-bold">{sale.customerName}</span>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="py-3 border-b border-slate-200">
              <table className="w-full text-left text-[11px]">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="pb-1 font-semibold">{t('product', lang)}</th>
                    <th className="pb-1 text-center font-semibold">{t('qty', lang)}</th>
                    <th className="pb-1 text-right font-semibold">{t('price', lang)}</th>
                    <th className="pb-1 text-right font-semibold">{t('amount', lang)}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sale.items.map((item, idx) => (
                    <tr key={idx} className="py-1">
                      <td className="py-1 font-medium pr-1">{item.productName}</td>
                      <td className="py-1 text-center">{item.quantity}</td>
                      <td className="py-1 text-right">{item.unitPrice.toFixed(2)}</td>
                      <td className="py-1 text-right font-bold">{item.subtotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals Section */}
            <div className="py-2.5 space-y-1 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>{t('subtotal', lang)}:</span>
                <span>{formatCurrency(sale.subtotal, business.currency, lang)}</span>
              </div>
              {sale.discountAmount > 0 && (
                <div className="flex justify-between text-rose-600 font-semibold">
                  <span>{t('discount', lang)}:</span>
                  <span>-{formatCurrency(sale.discountAmount, business.currency, lang)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-black text-slate-900 pt-1 border-t border-slate-300">
                <span>{t('total', lang)}:</span>
                <span>{formatCurrency(sale.totalAmount, business.currency, lang)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 pt-1">
                <span>{t('paymentMethod', lang)}:</span>
                <span className="font-bold">{sale.paymentMethod}</span>
              </div>
              {sale.paymentMethod === 'CASH' && sale.tenderedAmount && sale.tenderedAmount > 0 && (
                <>
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>{t('tenderedAmount', lang)}:</span>
                    <span>{formatCurrency(sale.tenderedAmount, business.currency, lang)}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-teal-700 font-bold">
                    <span>{t('changeDue', lang)}:</span>
                    <span>{formatCurrency(sale.changeAmount ?? sale.changeDue ?? 0, business.currency, lang)}</span>
                  </div>
                </>
              )}
            </div>

            {/* Receipt Footer */}
            <div className="text-center pt-3 border-t border-dashed border-slate-300 text-[10px] text-slate-500 space-y-0.5">
              <p className="font-bold text-slate-700">{settings.invoiceFooterNote || t('thankYouMessage', lang)}</p>
              <p>Powered by PocketBiz • Offline POS</p>
            </div>
          </div>
        </div>

        {/* Action Controls Bar (Print, Download PDF, WhatsApp) */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 grid grid-cols-3 gap-2 print:hidden">
          <button
            onClick={handlePrint}
            className="py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{t('print', lang)}</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>PDF</span>
          </button>

          <button
            onClick={handleShareWhatsApp}
            className="py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
