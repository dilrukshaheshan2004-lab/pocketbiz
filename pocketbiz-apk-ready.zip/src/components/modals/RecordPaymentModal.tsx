import React, { useState } from 'react';
import { X, DollarSign, CheckCircle2, Banknote, CreditCard, Building2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency } from '../../utils/formatters';
import { Customer, PaymentMethod } from '../../types';

interface RecordPaymentModalProps {
  customer: Customer;
  onClose: () => void;
}

export const RecordPaymentModal: React.FC<RecordPaymentModalProps> = ({ customer, onClose }) => {
  const { recordCustomerPayment, business, lang } = useApp();

  const [amount, setAmount] = useState<string>(String(customer.outstandingCredit));
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [notes, setNotes] = useState<string>('ණය පියවීම / Debt Settlement');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paidAmt = parseFloat(amount);
    if (!paidAmt || paidAmt <= 0) return;

    recordCustomerPayment(customer.id, paidAmt, paymentMethod, notes.trim() || undefined);
    onClose();
  };

  const handleSetFull = () => {
    setAmount(String(customer.outstandingCredit));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden z-10">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-sm font-bold">
              <DollarSign className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100">
              {t('recordPayment', lang)} (ණය පියවීම)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Customer Balance Box */}
          <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800 flex items-center justify-between">
            <div>
              <p className="font-bold text-xs text-slate-900 dark:text-slate-100">{customer.name}</p>
              <p className="text-[11px] text-slate-500">{customer.phone}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-amber-800 dark:text-amber-300 block font-semibold">
                ලැබිය යුතු මුළු ණය
              </span>
              <span className="font-black text-sm text-amber-700 dark:text-amber-300">
                {formatCurrency(customer.outstandingCredit, business.currency, lang)}
              </span>
            </div>
          </div>

          {/* Amount to Pay */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                ගෙවන මුදල ({business.currency}) *
              </label>
              <button
                type="button"
                onClick={handleSetFull}
                className="text-[11px] font-bold text-teal-600 hover:underline"
              >
                සම්පූර්ණ මුදල (Full Pay)
              </button>
            </div>
            <input
              type="number"
              step="0.01"
              max={customer.outstandingCredit}
              min="1"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-base font-extrabold text-emerald-600 dark:text-emerald-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              {t('paymentMethod', lang)}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'CASH', label: 'Cash (මුදල්)', icon: <Banknote className="w-3.5 h-3.5" /> },
                { id: 'CARD', label: 'Card', icon: <CreditCard className="w-3.5 h-3.5" /> },
                { id: 'BANK_TRANSFER', label: 'Bank Transfer', icon: <Building2 className="w-3.5 h-3.5" /> },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                  className={`p-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 ${
                    paymentMethod === m.id
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {m.icon}
                  <span>{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              සටහන (Note)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          {/* Remaining Balance Preview */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs">
            <span className="text-slate-600 dark:text-slate-400">ගෙවීමෙන් පසු ඉතිරි ණය:</span>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              {formatCurrency(
                Math.max(0, customer.outstandingCredit - (parseFloat(amount) || 0)),
                business.currency,
                lang
              )}
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
            >
              {t('cancel', lang)}
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('save', lang)}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
