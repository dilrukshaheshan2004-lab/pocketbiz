import React, { useState } from 'react';
import {
  Settings,
  Store,
  Globe,
  Lock,
  Database,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Volume2,
  VolumeX,
  AlertTriangle,
  FileSpreadsheet,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { Business, CurrencyCode } from '../../types';
import { storage } from '../../utils/storage';

export const SettingsScreen: React.FC = () => {
  const {
    business,
    updateBusiness,
    settings,
    updateSettings,
    lang,
    setLang,
    isDarkMode,
    toggleDarkMode,
    loadDemoData,
  } = useApp();

  // Profile Form State
  const [name, setName] = useState(business.name);
  const [ownerName, setOwnerName] = useState(business.ownerName || '');
  const [phone, setPhone] = useState(business.phone || '');
  const [address, setAddress] = useState(business.address || '');
  const [currency, setCurrency] = useState<CurrencyCode>(business.currency);
  const [logoUrl, setLogoUrl] = useState(business.logoUrl || '🏪');
  const [invoiceNote, setInvoiceNote] = useState(settings.invoiceFooterNote || '');

  // PIN Form State
  const [pinInput, setPinInput] = useState('');
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState('');

  const logoPresets = ['🏪', '🛒', '🛍️', '🍞', '🍰', '👗', '📱', '🔧', '📦', '☕', '🌾', '🧼'];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      name: name.trim() || 'PocketBiz Shop',
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      address: address.trim(),
      currency,
      currencySymbol: currency === 'LKR' ? 'Rs.' : currency,
      logoUrl,
    });
    updateSettings({ invoiceFooterNote: invoiceNote });
    setFeedbackMsg(lang === 'si' ? 'ව්‍යාපාර තොරතුරු සාර්ථකව සුරැකිණි!' : 'Business details saved successfully!');
    setTimeout(() => setFeedbackMsg(''), 3000);
  };

  const handleBackupJson = () => {
    const backupJson = storage.createBackupJson();
    const blob = new Blob([backupJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pocketbiz_backup_${business.name.replace(/\s+/g, '_')}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const jsonStr = event.target?.result as string;
        const res = storage.restoreBackupJson(jsonStr);
        if (res.success) {
          alert(lang === 'si' ? 'දත්ත සාර්ථකව Restore කරන ලදී! යෙදුම නැවත පූරණය වේ.' : 'Data restored successfully! App will reload.');
          window.location.reload();
        } else {
          alert('Failed to restore: ' + res.error);
        }
      } catch (err: any) {
        alert('Invalid backup file');
      }
    };
    reader.readAsText(file);
  };

  const handleSavePin = () => {
    if (pinInput.length === 4) {
      updateSettings({ pinCode: pinInput, isPinEnabled: true });
      setIsPinModalOpen(false);
      setPinInput('');
      setFeedbackMsg(lang === 'si' ? 'PIN අංකය සාර්ථකව ක්‍රියාත්මක කරන ලදී!' : 'PIN Lock enabled successfully!');
      setTimeout(() => setFeedbackMsg(''), 3000);
    } else {
      alert(lang === 'si' ? 'කරුණාකර ඉලක්කම් 4ක PIN අංකයක් ඇතුළත් කරන්න.' : 'Please enter a 4-digit PIN.');
    }
  };

  const handleDisablePin = () => {
    updateSettings({ isPinEnabled: false, pinCode: null });
    setFeedbackMsg(lang === 'si' ? 'PIN අංකය අක්‍රිය කරන ලදී.' : 'PIN Lock disabled.');
    setTimeout(() => setFeedbackMsg(''), 3000);
  };

  const handleResetData = () => {
    if (window.confirm(lang === 'si' ? 'ඔබට සියලු දත්ත මකා දමා මුල සිට ආරම්භ කිරීමට අවශ්‍යද?' : 'Are you sure you want to reset all store data?')) {
      storage.clearAll();
      window.location.reload();
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 pt-4 pb-28 space-y-6">
      {/* Top Header */}
      <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Settings className="w-5 h-5 text-teal-600" />
            <span>{t('settingsTitle', lang)}</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ව්‍යාපාර තොරතුරු, භාෂාව, ආරක්ෂාව සහ දත්ත කළමනාකරණය
          </p>
        </div>

        {feedbackMsg && (
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 px-3 py-1.5 rounded-xl animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>{feedbackMsg}</span>
          </div>
        )}
      </div>

      {/* 1. Business Profile Settings Form */}
      <form onSubmit={handleSaveProfile} className="bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
          <Store className="w-4 h-4 text-teal-600" />
          <span>{t('businessDetails', lang)}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              {t('businessName', lang)} *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              {t('ownerName', lang)}
            </label>
            <input
              type="text"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              {t('phoneNumber', lang)}
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              {t('currency', lang)}
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
            >
              <option value="LKR">LKR (රු. Sri Lanka)</option>
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="INR">INR (₹)</option>
              <option value="AED">AED</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
            {t('businessAddress', lang)}
          </label>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Logo Presets */}
        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
            {t('businessLogo', lang)} (Emoji Icon)
          </label>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {logoPresets.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setLogoUrl(preset)}
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 border transition-all ${
                  logoUrl === preset
                    ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-500 scale-110 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-750 border-slate-200 dark:border-slate-700'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Invoice Footer Note */}
        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
            {t('invoiceNote', lang)}
          </label>
          <input
            type="text"
            value={invoiceNote}
            onChange={(e) => setInvoiceNote(e.target.value)}
            placeholder="ස්තූතියි! නැවත එන්න."
            className="w-full bg-slate-50 dark:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
          />
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
        >
          {t('save', lang)}
        </button>
      </form>

      {/* 2. Preferences & Security */}
      <div className="bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
          <Globe className="w-4 h-4 text-blue-600" />
          <span>භාෂාව සහ මනාපයන් (Preferences)</span>
        </h3>

        {/* Language Selection */}
        <div className="flex items-center justify-between py-1">
          <div>
            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">{t('language', lang)}</p>
            <p className="text-xs text-slate-500">සිංහල / English භාෂාව තෝරන්න</p>
          </div>
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-750 p-1 rounded-xl text-xs">
            <button
              onClick={() => setLang('si')}
              className={`px-3 py-1.5 rounded-lg font-bold ${
                lang === 'si' ? 'bg-teal-600 text-white' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              සිංහල
            </button>
            <button
              onClick={() => setLang('en')}
              className={`px-3 py-1.5 rounded-lg font-bold ${
                lang === 'en' ? 'bg-teal-600 text-white' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* PIN Lock */}
        <div className="flex items-center justify-between py-2 border-t border-slate-100 dark:border-slate-700">
          <div>
            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-amber-500" />
              <span>{t('pinLock', lang)}</span>
            </p>
            <p className="text-xs text-slate-500">යෙදුම විවෘත කිරීමේදී PIN අංකයක් ඉල්ලන්න</p>
          </div>

          {settings.isPinEnabled ? (
            <button
              onClick={handleDisablePin}
              className="px-3 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold"
            >
              {t('disablePin', lang)}
            </button>
          ) : (
            <button
              onClick={() => setIsPinModalOpen(true)}
              className="px-3 py-1.5 bg-teal-600 text-white rounded-xl text-xs font-bold"
            >
              {t('enablePin', lang)}
            </button>
          )}
        </div>

        {/* Prevent Negative Stock Toggle */}
        <div className="flex items-center justify-between py-2 border-t border-slate-100 dark:border-slate-700">
          <div>
            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">Negative Stock වැළැක්වීම</p>
            <p className="text-xs text-slate-500">තොග අවසන් වූ විට විකිණීම තහනම් කරන්න</p>
          </div>
          <input
            type="checkbox"
            checked={!settings.allowNegativeStock}
            onChange={(e) => updateSettings({ allowNegativeStock: !e.target.checked })}
            className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
          />
        </div>

        {/* Sound Effects Toggle */}
        <div className="flex items-center justify-between py-2 border-t border-slate-100 dark:border-slate-700">
          <div>
            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">ශබ්ද සංඥා (Sound Effects)</p>
            <p className="text-xs text-slate-500">විකුණුම් අවසන් කිරීමේදී සහ බොත්තම් එබීමේදී</p>
          </div>
          <input
            type="checkbox"
            checked={settings.soundEnabled}
            onChange={(e) => updateSettings({ soundEnabled: e.target.checked })}
            className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
          />
        </div>
      </div>

      {/* 3. Backup & Restore */}
      <div className="bg-white dark:bg-slate-800/90 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-700">
          <Database className="w-4 h-4 text-emerald-600" />
          <span>{t('backupRestore', lang)}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={handleBackupJson}
            className="p-3.5 bg-slate-50 dark:bg-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl text-left flex items-start gap-3 transition-colors"
          >
            <Download className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">
                {t('backupData', lang)} (JSON File)
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                සියලු භාණ්ඩ, විකුණුම් සහ ගනුදෙනුකරුවන්ගේ දත්ත ෆයිල් එකක් ලෙස බාගත කරන්න.
              </p>
            </div>
          </button>

          <label className="p-3.5 bg-slate-50 dark:bg-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl text-left flex items-start gap-3 cursor-pointer transition-colors">
            <Upload className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-slate-100">
                {t('restoreData', lang)} (JSON Restore)
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                කලින් Backup ගත් ఫයිල් එකක් නැවත ඇතුළත් කරන්න.
              </p>
            </div>
            <input type="file" accept=".json" onChange={handleRestoreJson} className="hidden" />
          </label>
        </div>

        {/* Demo Data & Factory Reset */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-2">
          <button
            onClick={loadDemoData}
            className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1.5 py-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>ආදර්ශ Demo දත්ත නැවත පුරවන්න (Load Store Demo)</span>
          </button>

          <button
            onClick={handleResetData}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1.5 py-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>සියලු දත්ත මකන්න (Reset All Data)</span>
          </button>
        </div>
      </div>

      {/* About Box */}
      <div className="bg-slate-900 text-slate-300 p-5 rounded-2xl border border-slate-800 text-center space-y-2">
        <div className="w-10 h-10 rounded-xl bg-teal-500 text-slate-950 font-black text-sm flex items-center justify-center mx-auto shadow-md">
          PB
        </div>
        <h4 className="font-bold text-white text-sm">PocketBiz v1.0.0 (Offline-First Edition)</h4>
        <p className="text-xs text-slate-400">
          "ඔබේ ව්‍යාපාරය, ඔබේ අතේ." • 100% Client-Side Persistent Offline Engine
        </p>
      </div>

      {/* PIN Lock Setup Modal */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-xs w-full text-center space-y-4 shadow-2xl">
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mx-auto">
              <Lock className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100">
              {t('enterPin', lang)} (ඉලක්කම් 4ක්)
            </h4>
            <input
              type="password"
              maxLength={4}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="••••"
              className="w-36 mx-auto text-center tracking-widest text-2xl font-mono bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl py-2 focus:outline-none focus:border-teal-500"
            />
            <div className="flex gap-2">
              <button
                onClick={() => setIsPinModalOpen(false)}
                className="flex-1 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
              >
                {t('cancel', lang)}
              </button>
              <button
                onClick={handleSavePin}
                className="flex-1 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold"
              >
                {t('save', lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
