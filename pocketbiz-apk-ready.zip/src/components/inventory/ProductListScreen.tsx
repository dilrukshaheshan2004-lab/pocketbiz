import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  SlidersHorizontal,
  Package,
  AlertTriangle,
  CheckCircle2,
  History,
  Layers,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { formatCurrency } from '../../utils/formatters';
import { Product } from '../../types';
import { AddEditProductModal } from '../modals/AddEditProductModal';
import { StockAdjustModal } from '../modals/StockAdjustModal';
import { StockHistoryModal } from '../modals/StockHistoryModal';

export const ProductListScreen: React.FC = () => {
  const { products, categories, deleteProduct, business, lang } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK'>('ALL');
  const [sortBy, setSortBy] = useState<'name' | 'stockAsc' | 'stockDesc' | 'priceDesc'>('name');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [stockAdjustProduct, setStockAdjustProduct] = useState<Product | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Filtered & Sorted products
  const activeProducts = useMemo(() => {
    return products.filter((p) => !p.isDeleted);
  }, [products]);

  const filteredProducts = useMemo(() => {
    return activeProducts
      .filter((p) => {
        const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
        const q = searchQuery.trim().toLowerCase();
        const matchesQuery =
          !q ||
          p.name.toLowerCase().includes(q) ||
          (p.nameSi && p.nameSi.toLowerCase().includes(q)) ||
          p.sku.toLowerCase().includes(q);

        let matchesStatus = true;
        if (statusFilter === 'IN_STOCK') {
          matchesStatus = p.stockQuantity > p.lowStockLimit;
        } else if (statusFilter === 'LOW_STOCK') {
          matchesStatus = p.stockQuantity > 0 && p.stockQuantity <= p.lowStockLimit;
        } else if (statusFilter === 'OUT_OF_STOCK') {
          matchesStatus = p.stockQuantity <= 0;
        }

        return matchesCategory && matchesQuery && matchesStatus;
      })
      .sort((a, b) => {
        if (sortBy === 'name') return a.name.localeCompare(b.name);
        if (sortBy === 'stockAsc') return a.stockQuantity - b.stockQuantity;
        if (sortBy === 'stockDesc') return b.stockQuantity - a.stockQuantity;
        if (sortBy === 'priceDesc') return b.sellingPrice - a.sellingPrice;
        return 0;
      });
  }, [activeProducts, selectedCategory, searchQuery, statusFilter, sortBy]);

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(t('deleteProductConfirm', lang) + `\n(${name})`)) {
      deleteProduct(id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 pb-24 space-y-4">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Package className="w-5 h-5 text-teal-600" />
            <span>{t('productsTitle', lang)}</span>
            <span className="text-xs font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full">
              {activeProducts.length}
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            භාණ්ඩ මිල, තොග ප්‍රමාණයන් සහ ගැලපුම් කළමනාකරණය
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <History className="w-3.5 h-3.5" />
            <span>{t('movementHistory', lang)}</span>
          </button>

          <button
            id="add-product-main-btn"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-teal-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addProductTitle', lang)}</span>
          </button>
        </div>
      </div>

      {/* Search, Status & Category Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search', lang)}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Status Filter */}
        <div className="flex bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-1 text-xs">
          {[
            { id: 'ALL', label: t('all', lang) },
            { id: 'IN_STOCK', label: 'තොග ඇත' },
            { id: 'LOW_STOCK', label: 'අඩුයි' },
            { id: 'OUT_OF_STOCK', label: 'අවසන්' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setStatusFilter(item.id as any)}
              className={`flex-1 py-1 px-1.5 rounded-lg text-[11px] font-bold transition-colors ${
                statusFilter === item.id
                  ? 'bg-teal-600 text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Category & Sort */}
        <div className="flex gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
          >
            <option value="ALL">{t('allCategories', lang)}</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>
                {lang === 'si' && c.nameSi ? c.nameSi : c.name}
              </option>
            ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
          >
            <option value="name">නම අනුව</option>
            <option value="stockAsc">අඩු තොග මුලින්</option>
            <option value="stockDesc">වැඩි තොග මුලින්</option>
            <option value="priceDesc">මිල ඉහළ සිට</option>
          </select>
        </div>
      </div>

      {/* Product List / Table */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 p-12 text-center">
          <Package className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('noProducts', lang)}</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">{t('noProductsDesc', lang)}</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="mt-4 px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addProductTitle', lang)}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredProducts.map((product) => {
            const isOutOfStock = product.stockQuantity <= 0;
            const isLowStock = product.stockQuantity > 0 && product.stockQuantity <= product.lowStockLimit;
            const profitPerUnit = product.sellingPrice - product.costPrice;
            const marginPercent = product.sellingPrice > 0 ? (profitPerUnit / product.sellingPrice) * 100 : 0;

            return (
              <div
                key={product.id}
                className={`bg-white dark:bg-slate-800/90 rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                  isOutOfStock
                    ? 'border-rose-300 dark:border-rose-900/50 bg-rose-50/20'
                    : isLowStock
                    ? 'border-amber-300 dark:border-amber-900/50 bg-amber-50/20'
                    : 'border-slate-200 dark:border-slate-700/80 shadow-xs'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-xl shrink-0">
                        {product.imageUrl || '📦'}
                      </span>
                      <div className="min-w-0">
                        <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 truncate">
                          {product.nameSi || product.name}
                        </h4>
                        <p className="text-[10px] text-slate-500 font-mono">
                          SKU: {product.sku} • {product.category}
                        </p>
                      </div>
                    </div>

                    {/* Stock Status Badge */}
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 border ${
                        isOutOfStock
                          ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800'
                          : isLowStock
                          ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                      }`}
                    >
                      {isOutOfStock ? t('outOfStock', lang) : isLowStock ? t('lowStock', lang) : t('inStock', lang)}
                    </span>
                  </div>

                  {/* Pricing and Stock Info */}
                  <div className="grid grid-cols-2 gap-2 my-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-750 border border-slate-100 dark:border-slate-700/60 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-500 block">{t('sellingPrice', lang)}</span>
                      <span className="font-bold text-teal-700 dark:text-teal-300 text-sm">
                        {formatCurrency(product.sellingPrice, business.currency, lang)}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        පිරිවැය: {formatCurrency(product.costPrice, business.currency, lang)}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 block">{t('stockQuantity', lang)}</span>
                      <span
                        className={`font-black text-sm ${
                          isOutOfStock
                            ? 'text-rose-600'
                            : isLowStock
                            ? 'text-amber-600'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {product.stockQuantity} {product.unit}
                      </span>
                      <span className="text-[10px] text-emerald-600 block mt-0.5 font-semibold">
                        ලාභය: {marginPercent.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center justify-between gap-1 pt-2 border-t border-slate-100 dark:border-slate-700/60">
                  <button
                    type="button"
                    onClick={() => setStockAdjustProduct(product)}
                    className="px-3 py-1.5 bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>{t('stockManagement', lang)}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setEditingProduct(product)}
                      className="p-2 text-slate-600 dark:text-slate-300 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
                      title={t('edit', lang)}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(product.id, product.name)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors"
                      title={t('delete', lang)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modals */}
      {isAddModalOpen && (
        <AddEditProductModal
          onClose={() => setIsAddModalOpen(false)}
        />
      )}

      {editingProduct && (
        <AddEditProductModal
          productToEdit={editingProduct}
          onClose={() => setEditingProduct(null)}
        />
      )}

      {stockAdjustProduct && (
        <StockAdjustModal
          product={stockAdjustProduct}
          onClose={() => setStockAdjustProduct(null)}
        />
      )}

      {isHistoryOpen && (
        <StockHistoryModal
          onClose={() => setIsHistoryOpen(false)}
        />
      )}
    </div>
  );
};
