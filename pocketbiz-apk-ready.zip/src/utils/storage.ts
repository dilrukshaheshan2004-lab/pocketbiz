import {
  Business,
  Product,
  Category,
  Customer,
  Sale,
  Expense,
  Payment,
  StockMovement,
  AppSettings,
} from '../types';

const STORAGE_KEYS = {
  BUSINESS: 'pocketbiz_business',
  PRODUCTS: 'pocketbiz_products',
  CATEGORIES: 'pocketbiz_categories',
  CUSTOMERS: 'pocketbiz_customers',
  SALES: 'pocketbiz_sales',
  EXPENSES: 'pocketbiz_expenses',
  PAYMENTS: 'pocketbiz_payments',
  STOCK_MOVEMENTS: 'pocketbiz_stock_movements',
  SETTINGS: 'pocketbiz_settings',
  INITIALIZED: 'pocketbiz_initialized',
};

export const defaultSettings: AppSettings = {
  language: 'si',
  theme: 'light',
  pinEnabled: false,
  pinHash: '',
  notificationsEnabled: true,
  lowStockAlerts: true,
  creditDueAlerts: true,
  allowNegativeStock: false,
  printThermalReceipt: true,
  autoGenerateInvoiceNumber: true,
  isProUnlocked: true,
};

export const defaultBusiness: Business = {
  id: 'biz_default_01',
  name: 'නිමල් ස්ටෝර්ස් (Nimal Stores)',
  ownerName: 'කසුන් පෙරේරා',
  phone: '071 234 5678',
  address: 'නො. 45, ප්‍රධාන වීදිය, මහරගම',
  currency: 'LKR',
  currencySymbol: 'Rs.',
  email: 'nimalstores@pocketbiz.lk',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

export const defaultCategories: Category[] = [
  { id: 'cat_1', businessId: 'biz_default_01', name: 'Groceries', nameSi: 'ධාන්‍ය හා වියළි ආහාර', icon: 'ShoppingBag', color: 'teal' },
  { id: 'cat_2', businessId: 'biz_default_01', name: 'Dairy & Drinks', nameSi: 'කිරි සහ බීම වර්ග', icon: 'Coffee', color: 'blue' },
  { id: 'cat_3', businessId: 'biz_default_01', name: 'Snacks & Biscuits', nameSi: 'බිස්කට් සහ කෙටි ආහාර', icon: 'Cookie', color: 'amber' },
  { id: 'cat_4', businessId: 'biz_default_01', name: 'Personal Care', nameSi: 'පිරිසිදුකාරක හා සබන්', icon: 'Sparkles', color: 'purple' },
  { id: 'cat_5', businessId: 'biz_default_01', name: 'Oils & Spices', nameSi: 'තෙල් සහ කුළුබඩු', icon: 'Flame', color: 'rose' },
];

export const sampleProducts: Product[] = [
  {
    id: 'prod_1',
    businessId: 'biz_default_01',
    name: 'Keeri Samba Rice 5kg',
    nameSi: 'කීරි සම්බා සහල් 5kg',
    sku: 'RIC-001',
    category: 'Groceries',
    sellingPrice: 1550,
    costPrice: 1320,
    stockQuantity: 24,
    lowStockLimit: 5,
    unit: 'packet',
    imageUrl: '🌾',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_2',
    businessId: 'biz_default_01',
    name: 'White Sugar 1kg',
    nameSi: 'සුදු සීනි 1kg',
    sku: 'SUG-002',
    category: 'Groceries',
    sellingPrice: 280,
    costPrice: 240,
    stockQuantity: 45,
    lowStockLimit: 10,
    unit: 'kg',
    imageUrl: '🍚',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_3',
    businessId: 'biz_default_01',
    name: 'Highland Milk Powder 400g',
    nameSi: 'හයිලන්ඩ් කිරිපිටි 400g',
    sku: 'MLK-003',
    category: 'Dairy & Drinks',
    sellingPrice: 1120,
    costPrice: 980,
    stockQuantity: 4, // Low stock
    lowStockLimit: 6,
    unit: 'packet',
    imageUrl: '🥛',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_4',
    businessId: 'biz_default_01',
    name: 'Munchee Super Cream Cracker',
    nameSi: 'මුන්චි ක්‍රීම් ක්‍රැකර් 490g',
    sku: 'BIS-004',
    category: 'Snacks & Biscuits',
    sellingPrice: 420,
    costPrice: 350,
    stockQuantity: 32,
    lowStockLimit: 8,
    unit: 'packet',
    imageUrl: '🍪',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_5',
    businessId: 'biz_default_01',
    name: 'EGB Ginger Beer 400ml',
    nameSi: 'ජින්ජර් බියර් (EGB) 400ml',
    sku: 'DRK-005',
    category: 'Dairy & Drinks',
    sellingPrice: 180,
    costPrice: 140,
    stockQuantity: 2, // Low stock
    lowStockLimit: 10,
    unit: 'bottle',
    imageUrl: '🥤',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_6',
    businessId: 'biz_default_01',
    name: 'Sunlight Lemon Bar 100g',
    nameSi: 'සන්ලයිට් සබන් කැටය',
    sku: 'SOP-006',
    category: 'Personal Care',
    sellingPrice: 160,
    costPrice: 125,
    stockQuantity: 50,
    lowStockLimit: 12,
    unit: 'pcs',
    imageUrl: '🧼',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_7',
    businessId: 'biz_default_01',
    name: 'Fortune Coconut Oil 1L',
    nameSi: 'පිරිසිදු පොල්තෙල් 1L',
    sku: 'OIL-007',
    category: 'Oils & Spices',
    sellingPrice: 890,
    costPrice: 760,
    stockQuantity: 0, // Out of stock
    lowStockLimit: 5,
    unit: 'bottle',
    imageUrl: '🥥',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_8',
    businessId: 'biz_default_01',
    name: 'Samaposha 200g',
    nameSi: 'සමපෝෂ 200g පැකට්ටුව',
    sku: 'SMP-008',
    category: 'Groceries',
    sellingPrice: 220,
    costPrice: 175,
    stockQuantity: 18,
    lowStockLimit: 6,
    unit: 'packet',
    imageUrl: '🥣',
    isDeleted: false,
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const sampleCustomers: Customer[] = [
  {
    id: 'cust_1',
    businessId: 'biz_default_01',
    name: 'කසුන් අමරසිංහ (Kasun)',
    phone: '077 123 4567',
    address: 'නො. 18, පන්සල පාර, මහරගම',
    notes: 'නිරන්තරයෙන් භාණ්ඩ ගන්නා විශ්වාසවන්ත පාරිභෝගිකයෙකි.',
    creditLimit: 25000,
    totalPurchases: 48500,
    outstandingCredit: 6500,
    isDeleted: false,
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'cust_2',
    businessId: 'biz_default_01',
    name: 'නිමල් ජයසිංහ (Nimal)',
    phone: '071 987 6543',
    address: 'නො. 34, ස්ටේෂන් පාර, කොට්ටාව',
    notes: 'සතිපතා බිල්පත් ගෙවයි.',
    creditLimit: 15000,
    totalPurchases: 32000,
    outstandingCredit: 3800,
    isDeleted: false,
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'cust_3',
    businessId: 'biz_default_01',
    name: 'අමාලි වික්‍රමසිංහ (Amali)',
    phone: '078 555 1234',
    address: 'නො. 08, විහාර මාවත, නුගේගොඩ',
    notes: 'Home Bakery හිමිකාරිනියකි.',
    creditLimit: 30000,
    totalPurchases: 64200,
    outstandingCredit: 0,
    isDeleted: false,
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'cust_4',
    businessId: 'biz_default_01',
    name: 'රුවන් සේනානායක (Ruwan)',
    phone: '072 333 4455',
    address: 'නො. 90, උසාවිය පාර, හෝමාගම',
    notes: 'ණය කාලය ඉක්මවා ඇත.',
    creditLimit: 10000,
    totalPurchases: 18400,
    outstandingCredit: 5200,
    isDeleted: false,
    createdAt: new Date(Date.now() - 45 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const sampleExpenses: Expense[] = [
  {
    id: 'exp_1',
    businessId: 'biz_default_01',
    title: 'මාසික කඩ කාමර කුලිය (Shop Rent)',
    amount: 15000,
    category: 'Rent',
    date: new Date(Date.now() - 2 * 86400000).toISOString(),
    notes: 'අගෝස්තු මස කුලිය ගෙවන ලදී.',
    isDeleted: false,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'exp_2',
    businessId: 'biz_default_01',
    title: 'විදුලි බිල (Electricity Bill)',
    amount: 4250,
    category: 'Electricity',
    date: new Date(Date.now() - 1 * 86400000).toISOString(),
    notes: 'CEB බිල්පත පියවන ලදී.',
    isDeleted: false,
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'exp_3',
    businessId: 'biz_default_01',
    title: 'තොග ගෙන ඒමේ ප්‍රවාහන ගාස්තු (Lorry Transport)',
    amount: 2500,
    category: 'Transport',
    date: new Date().toISOString(),
    notes: 'පෑලියගොඩ සිට බඩු ගෙන ඒම.',
    isDeleted: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'exp_4',
    businessId: 'biz_default_01',
    title: 'තේ සහ සේවක දිවා ආහාර (Tea & Meals)',
    amount: 850,
    category: 'Tea & Meals',
    date: new Date().toISOString(),
    notes: 'අද දින තේ වියදම.',
    isDeleted: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const sampleSales: Sale[] = [
  {
    id: 'sale_1',
    businessId: 'biz_default_01',
    invoiceNumber: 'PB-20260816-0001',
    customerId: 'cust_1',
    customerName: 'කසුන් අමරසිංහ (Kasun)',
    customerPhone: '077 123 4567',
    items: [
      {
        id: 'item_1_1',
        saleId: 'sale_1',
        productId: 'prod_1',
        productName: 'Keeri Samba Rice 5kg',
        sku: 'RIC-001',
        quantity: 2,
        unitPrice: 1550,
        costPrice: 1320,
        subtotal: 3100,
        profit: 460,
      },
      {
        id: 'item_1_2',
        saleId: 'sale_1',
        productId: 'prod_2',
        productName: 'White Sugar 1kg',
        sku: 'SUG-002',
        quantity: 3,
        unitPrice: 280,
        costPrice: 240,
        subtotal: 840,
        profit: 120,
      },
    ],
    subtotal: 3940,
    discountType: 'fixed',
    discountValue: 140,
    discountAmount: 140,
    totalAmount: 3800,
    costTotal: 3360,
    profit: 440,
    paymentMethod: 'CASH',
    paymentStatus: 'PAID',
    paidAmount: 3800,
    remainingBalance: 0,
    tenderedAmount: 4000,
    changeAmount: 200,
    notes: 'මුදල් ගෙවා නිම කරන ලදී.',
    isVoided: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sale_2',
    businessId: 'biz_default_01',
    invoiceNumber: 'PB-20260816-0002',
    customerId: 'cust_2',
    customerName: 'නිමල් ජයසිංහ (Nimal)',
    customerPhone: '071 987 6543',
    items: [
      {
        id: 'item_2_1',
        saleId: 'sale_2',
        productId: 'prod_3',
        productName: 'Highland Milk Powder 400g',
        sku: 'MLK-003',
        quantity: 2,
        unitPrice: 1120,
        costPrice: 980,
        subtotal: 2240,
        profit: 280,
      },
      {
        id: 'item_2_2',
        saleId: 'sale_2',
        productId: 'prod_4',
        productName: 'Munchee Super Cream Cracker',
        sku: 'BIS-004',
        quantity: 3,
        unitPrice: 420,
        costPrice: 350,
        subtotal: 1260,
        profit: 210,
      },
    ],
    subtotal: 3500,
    discountType: 'percentage',
    discountValue: 0,
    discountAmount: 0,
    totalAmount: 3500,
    costTotal: 3010,
    profit: 490,
    paymentMethod: 'CREDIT',
    paymentStatus: 'CREDIT',
    paidAmount: 0,
    remainingBalance: 3500,
    notes: 'ණය පදනම මත ලබා දෙන ලදී.',
    isVoided: false,
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sale_3',
    businessId: 'biz_default_01',
    invoiceNumber: 'PB-20260816-0003',
    customerName: 'Walk-in Customer (සාමාන්‍ය පාරිභෝගිකයා)',
    items: [
      {
        id: 'item_3_1',
        saleId: 'sale_3',
        productId: 'prod_6',
        productName: 'Sunlight Lemon Bar 100g',
        sku: 'SOP-006',
        quantity: 4,
        unitPrice: 160,
        costPrice: 125,
        subtotal: 640,
        profit: 140,
      },
      {
        id: 'item_3_2',
        saleId: 'sale_3',
        productId: 'prod_5',
        productName: 'EGB Ginger Beer 400ml',
        sku: 'DRK-005',
        quantity: 2,
        unitPrice: 180,
        costPrice: 140,
        subtotal: 360,
        profit: 80,
      },
    ],
    subtotal: 1000,
    discountType: 'percentage',
    discountValue: 0,
    discountAmount: 0,
    totalAmount: 1000,
    costTotal: 780,
    profit: 220,
    paymentMethod: 'CARD',
    paymentStatus: 'PAID',
    paidAmount: 1000,
    remainingBalance: 0,
    notes: 'කාඩ්පත් මගින් ගෙවන ලදී.',
    isVoided: false,
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    if (!data) return defaultValue;
    return JSON.parse(data) as T;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error('Storage set error:', e);
  }
}

export const storage = {
  get<T>(key: string, defaultValue: T): T {
    return getItem<T>(key, defaultValue);
  },

  set<T>(key: string, value: T): void {
    setItem<T>(key, value);
  },

  getBusiness(): Business | null {
    return getItem<Business | null>(STORAGE_KEYS.BUSINESS, null);
  },

  saveBusiness(business: Business): void {
    setItem(STORAGE_KEYS.BUSINESS, business);
  },

  getProducts(): Product[] {
    return getItem<Product[]>(STORAGE_KEYS.PRODUCTS, []);
  },

  saveProducts(products: Product[]): void {
    setItem(STORAGE_KEYS.PRODUCTS, products);
  },

  getCategories(): Category[] {
    return getItem<Category[]>(STORAGE_KEYS.CATEGORIES, defaultCategories);
  },

  saveCategories(categories: Category[]): void {
    setItem(STORAGE_KEYS.CATEGORIES, categories);
  },

  getCustomers(): Customer[] {
    return getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
  },

  saveCustomers(customers: Customer[]): void {
    setItem(STORAGE_KEYS.CUSTOMERS, customers);
  },

  getSales(): Sale[] {
    return getItem<Sale[]>(STORAGE_KEYS.SALES, []);
  },

  saveSales(sales: Sale[]): void {
    setItem(STORAGE_KEYS.SALES, sales);
  },

  getExpenses(): Expense[] {
    return getItem<Expense[]>(STORAGE_KEYS.EXPENSES, []);
  },

  saveExpenses(expenses: Expense[]): void {
    setItem(STORAGE_KEYS.EXPENSES, expenses);
  },

  getPayments(): Payment[] {
    return getItem<Payment[]>(STORAGE_KEYS.PAYMENTS, []);
  },

  savePayments(payments: Payment[]): void {
    setItem(STORAGE_KEYS.PAYMENTS, payments);
  },

  getStockMovements(): StockMovement[] {
    return getItem<StockMovement[]>(STORAGE_KEYS.STOCK_MOVEMENTS, []);
  },

  saveStockMovements(movements: StockMovement[]): void {
    setItem(STORAGE_KEYS.STOCK_MOVEMENTS, movements);
  },

  getSettings(): AppSettings {
    return getItem<AppSettings>(STORAGE_KEYS.SETTINGS, defaultSettings);
  },

  saveSettings(settings: AppSettings): void {
    setItem(STORAGE_KEYS.SETTINGS, settings);
  },

  isInitialized(): boolean {
    return localStorage.getItem(STORAGE_KEYS.INITIALIZED) === 'true';
  },

  setInitialized(val: boolean): void {
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, val ? 'true' : 'false');
  },

  loadDemoData(): void {
    this.saveBusiness(defaultBusiness);
    this.saveProducts(sampleProducts);
    this.saveCategories(defaultCategories);
    this.saveCustomers(sampleCustomers);
    this.saveExpenses(sampleExpenses);
    this.saveSales(sampleSales);

    // Initial stock movements for demo
    const initialMovements: StockMovement[] = sampleProducts.map((p) => ({
      id: `mov_demo_${p.id}`,
      businessId: 'biz_default_01',
      productId: p.id,
      productName: p.name,
      type: 'PURCHASE',
      quantity: p.stockQuantity,
      previousStock: 0,
      previousQuantity: 0,
      newStock: p.stockQuantity,
      newQuantity: p.stockQuantity,
      reason: 'ආරම්භක තොග ඇතුළත් කිරීම (Initial Stock)',
      date: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    }));
    this.saveStockMovements(initialMovements);
    this.setInitialized(true);
  },

  clearAll(): void {
    localStorage.clear();
  },

  clearAllData(): void {
    localStorage.clear();
  },

  createBackupJson(): string {
    return this.exportBackupJson();
  },

  exportBackupJson(): string {
    const backup = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      appName: 'PocketBiz',
      business: this.getBusiness(),
      settings: this.getSettings(),
      categories: this.getCategories(),
      products: this.getProducts(),
      customers: this.getCustomers(),
      sales: this.getSales(),
      expenses: this.getExpenses(),
      payments: this.getPayments(),
      stockMovements: this.getStockMovements(),
    };
    return JSON.stringify(backup, null, 2);
  },

  restoreBackupJson(jsonString: string): { success: boolean; message: string; error?: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data || typeof data !== 'object') {
        return { success: false, message: 'Invalid backup file format', error: 'Invalid format' };
      }

      if (data.business) this.saveBusiness(data.business);
      if (Array.isArray(data.products)) this.saveProducts(data.products);
      if (Array.isArray(data.categories)) this.saveCategories(data.categories);
      if (Array.isArray(data.customers)) this.saveCustomers(data.customers);
      if (Array.isArray(data.sales)) this.saveSales(data.sales);
      if (Array.isArray(data.expenses)) this.saveExpenses(data.expenses);
      if (Array.isArray(data.payments)) this.savePayments(data.payments);
      if (Array.isArray(data.stockMovements)) this.saveStockMovements(data.stockMovements);
      if (data.settings) this.saveSettings({ ...defaultSettings, ...data.settings });

      this.setInitialized(true);
      return { success: true, message: 'Backup restored successfully' };
    } catch {
      return { success: false, message: 'Failed to parse backup JSON file', error: 'Failed to parse' };
    }
  },

  exportCsv(type: 'products' | 'sales' | 'customers' | 'expenses'): string {
    let headers: string[] = [];
    let rows: string[][] = [];

    if (type === 'products') {
      headers = ['ID', 'Name', 'SKU', 'Category', 'Selling Price', 'Cost Price', 'Stock Quantity', 'Unit'];
      const products = this.getProducts().filter((p) => !p.isDeleted);
      rows = products.map((p) => [
        p.id,
        `"${p.name.replace(/"/g, '""')}"`,
        p.sku,
        p.category,
        String(p.sellingPrice),
        String(p.costPrice),
        String(p.stockQuantity),
        p.unit,
      ]);
    } else if (type === 'sales') {
      headers = ['Invoice No', 'Date', 'Customer', 'Subtotal', 'Discount', 'Total', 'Payment Method', 'Payment Status', 'Profit'];
      const sales = this.getSales().filter((s) => !s.isVoided);
      rows = sales.map((s) => [
        s.invoiceNumber,
        s.createdAt,
        `"${(s.customerName || 'Walk-in').replace(/"/g, '""')}"`,
        String(s.subtotal),
        String(s.discountAmount),
        String(s.totalAmount),
        s.paymentMethod,
        s.paymentStatus,
        String(s.profit),
      ]);
    } else if (type === 'customers') {
      headers = ['ID', 'Name', 'Phone', 'Address', 'Total Purchases', 'Outstanding Credit'];
      const customers = this.getCustomers().filter((c) => !c.isDeleted);
      rows = customers.map((c) => [
        c.id,
        `"${c.name.replace(/"/g, '""')}"`,
        c.phone,
        `"${(c.address || '').replace(/"/g, '""')}"`,
        String(c.totalPurchases),
        String(c.outstandingCredit),
      ]);
    } else if (type === 'expenses') {
      headers = ['ID', 'Date', 'Title', 'Category', 'Amount', 'Notes'];
      const expenses = this.getExpenses().filter((e) => !e.isDeleted);
      rows = expenses.map((e) => [
        e.id,
        e.date,
        `"${e.title.replace(/"/g, '""')}"`,
        e.category,
        String(e.amount),
        `"${(e.notes || '').replace(/"/g, '""')}"`,
      ]);
    }

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    return csvContent;
  },
};
