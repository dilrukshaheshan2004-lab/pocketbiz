import { CurrencyCode, Language } from '../types';

export function formatCurrency(
  amount: number,
  currency: CurrencyCode = 'LKR',
  lang: Language = 'si'
): string {
  const safeAmount = Number.isFinite(amount) ? amount : 0;
  const formattedNumber = safeAmount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  if (currency === 'LKR') {
    return lang === 'si' ? `රු. ${formattedNumber}` : `LKR ${formattedNumber}`;
  }

  const symbols: Record<CurrencyCode, string> = {
    LKR: 'LKR',
    USD: '$',
    EUR: '€',
    GBP: '£',
    INR: '₹',
    AED: 'AED',
    SAR: 'SAR',
  };

  const sym = symbols[currency] || currency;
  return `${sym} ${formattedNumber}`;
}

export function formatDate(dateString: string, lang: Language = 'si'): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;

    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };

    return date.toLocaleDateString(lang === 'si' ? 'si-LK' : 'en-US', options);
  } catch {
    return dateString;
  }
}

export function formatDateOnly(dateString: string): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return date.toISOString().split('T')[0];
  } catch {
    return dateString;
  }
}

export function generateInvoiceNumber(sequence: number): string {
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const dd = String(today.getDate()).padStart(2, '0');
  const seq = String(sequence).padStart(4, '0');
  return `PB-${yyyy}${mm}${dd}-${seq}`;
}

export function generateSku(productName: string, count: number): string {
  const clean = productName.replace(/[^a-zA-Z0-9]/g, '').slice(0, 3).toUpperCase() || 'PRD';
  const seq = String(count + 1).padStart(3, '0');
  return `${clean}-${seq}`;
}

export function calculateProfit(
  sellingPrice: number,
  costPrice: number,
  quantity: number
): { revenue: number; cogs: number; grossProfit: number; marginPercent: number } {
  const revenue = sellingPrice * quantity;
  const cogs = costPrice * quantity;
  const grossProfit = revenue - cogs;
  const marginPercent = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
  return { revenue, cogs, grossProfit, marginPercent };
}
