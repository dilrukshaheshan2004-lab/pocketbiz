import { jsPDF } from 'jspdf';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';
import { Business, Sale, Language } from '../types';
import { formatCurrency, formatDate } from './formatters';

export function generateInvoicePdf(sale: Sale, business: Business, lang: Language = 'si'): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 20;

  // Header Banner
  doc.setFillColor(13, 148, 136); // Teal 600
  doc.rect(0, 0, pageWidth, 12, 'F');

  // Business Name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(15, 23, 42); // Slate 900
  doc.text(business.name, 15, y);
  y += 7;

  // Business details
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105); // Slate 600
  if (business.address) {
    doc.text(business.address, 15, y);
    y += 5;
  }
  if (business.phone) {
    doc.text(`Phone: ${business.phone}`, 15, y);
    y += 5;
  }

  // Invoice Title & Info on top right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(13, 148, 136);
  doc.text('INVOICE / බිල්පත', pageWidth - 15, 20, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`Invoice No: ${sale.invoiceNumber}`, pageWidth - 15, 28, { align: 'right' });
  doc.text(`Date: ${formatDate(sale.createdAt, 'en')}`, pageWidth - 15, 34, { align: 'right' });
  doc.text(`Payment: ${sale.paymentMethod}`, pageWidth - 15, 40, { align: 'right' });

  // Divider Line
  y = Math.max(y + 4, 46);
  doc.setDrawColor(226, 232, 240);
  doc.line(15, y, pageWidth - 15, y);
  y += 8;

  // Bill To Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(15, y, pageWidth - 30, 20, 2, 2, 'F');
  
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('BILL TO / පාරිභෝගිකයා:', 20, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.text(sale.customerName || 'Walk-in Customer', 20, y + 12);
  if (sale.customerPhone) {
    doc.text(`Phone: ${sale.customerPhone}`, 20, y + 17);
  }
  y += 26;

  // Items Table Header
  doc.setFillColor(241, 245, 249);
  doc.rect(15, y, pageWidth - 30, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  doc.text('#', 18, y + 5.5);
  doc.text('Item Description', 28, y + 5.5);
  doc.text('Qty', 115, y + 5.5, { align: 'center' });
  doc.text(`Unit Price (${business.currency})`, 145, y + 5.5, { align: 'right' });
  doc.text(`Total (${business.currency})`, pageWidth - 20, y + 5.5, { align: 'right' });
  y += 10;

  // Items Rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);

  sale.items.forEach((item, index) => {
    // Alternate row bg
    if (index % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(15, y - 2, pageWidth - 30, 7, 'F');
    }

    doc.text(String(index + 1), 18, y + 3);
    doc.text(item.productName, 28, y + 3);
    doc.text(String(item.quantity), 115, y + 3, { align: 'center' });
    doc.text(item.unitPrice.toFixed(2), 145, y + 3, { align: 'right' });
    doc.text(item.subtotal.toFixed(2), pageWidth - 20, y + 3, { align: 'right' });

    y += 7;
  });

  // Table Bottom Line
  doc.setDrawColor(226, 232, 240);
  doc.line(15, y, pageWidth - 15, y);
  y += 6;

  // Summary Table (Right Aligned)
  const summaryX = pageWidth - 80;
  doc.setFontSize(10);
  
  // Subtotal
  doc.setFont('helvetica', 'normal');
  doc.text('Subtotal:', summaryX, y);
  doc.text(sale.subtotal.toFixed(2), pageWidth - 20, y, { align: 'right' });
  y += 6;

  // Discount if any
  if (sale.discountAmount > 0) {
    doc.setTextColor(220, 38, 38);
    doc.text('Discount:', summaryX, y);
    doc.text(`-${sale.discountAmount.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });
    doc.setTextColor(15, 23, 42);
    y += 6;
  }

  // Grand Total
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setFillColor(240, 253, 250); // Teal 50
  doc.roundedRect(summaryX - 5, y - 4, 70, 9, 1, 1, 'F');
  doc.setTextColor(13, 148, 136);
  doc.text(`Total (${business.currency}):`, summaryX, y + 2.5);
  doc.text(sale.totalAmount.toFixed(2), pageWidth - 20, y + 2.5, { align: 'right' });
  y += 12;

  // Payment Breakdown
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);

  if (sale.paymentMethod === 'CREDIT') {
    doc.text(`Paid: 0.00`, summaryX, y);
    doc.setTextColor(220, 38, 38);
    doc.text(`Balance Due: ${sale.totalAmount.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });
  } else {
    doc.text(`Paid: ${sale.paidAmount.toFixed(2)}`, summaryX, y);
    if (sale.changeAmount && sale.changeAmount > 0) {
      doc.text(`Change: ${sale.changeAmount.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });
    } else {
      doc.text(`Status: Fully Paid`, pageWidth - 20, y, { align: 'right' });
    }
  }

  // Footer
  y = Math.max(y + 20, 260);
  doc.setDrawColor(226, 232, 240);
  doc.line(15, y, pageWidth - 15, y);
  y += 6;

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Thank you for your business! / අප සමඟ ගනුදෙනු කළ ඔබට ස්තූතියි!', pageWidth / 2, y, { align: 'center' });
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Generated by PocketBiz • Offline Business Management`, pageWidth / 2, y, { align: 'center' });

  return doc;
}

export function generateReceiptPdf(sale: Sale, business: Business, lang: Language = 'si'): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [80, 200],
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 10;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(business.name, pageWidth / 2, y, { align: 'center' });
  y += 5;

  if (business.address) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(business.address, pageWidth / 2, y, { align: 'center' });
    y += 4;
  }
  if (business.phone) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Tel: ${business.phone}`, pageWidth / 2, y, { align: 'center' });
    y += 4;
  }

  doc.setLineDashPattern([1, 1], 0);
  doc.line(5, y, pageWidth - 5, y);
  y += 4;

  doc.setFontSize(8);
  doc.text(`Inv: ${sale.invoiceNumber}`, 5, y);
  doc.text(formatDate(sale.createdAt, 'en'), pageWidth - 5, y, { align: 'right' });
  y += 4;
  doc.text(`Cust: ${sale.customerName}`, 5, y);
  y += 4;

  doc.line(5, y, pageWidth - 5, y);
  y += 4;

  sale.items.forEach((item) => {
    doc.text(item.productName, 5, y);
    y += 3.5;
    doc.text(`${item.quantity} x ${item.unitPrice.toFixed(2)}`, 5, y);
    doc.text(item.subtotal.toFixed(2), pageWidth - 5, y, { align: 'right' });
    y += 4;
  });

  doc.line(5, y, pageWidth - 5, y);
  y += 4;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(`TOTAL: ${business.currency} ${sale.totalAmount.toFixed(2)}`, pageWidth - 5, y, { align: 'right' });
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Paid: ${sale.paymentMethod}`, 5, y);
  y += 6;

  doc.text('Thank you! Come again.', pageWidth / 2, y, { align: 'center' });

  doc.save(`${sale.invoiceNumber}_slip.pdf`);
  return doc;
}

export function downloadInvoicePdf(sale: Sale, business: Business, lang: Language = 'si'): void {
  const doc = generateInvoicePdf(sale, business, lang);
  doc.save(`${sale.invoiceNumber}.pdf`);
}

export async function shareViaWhatsApp(sale: Sale, business: Business, lang: Language = 'si'): Promise<void> {
  const formattedTotal = formatCurrency(sale.totalAmount, business.currency, lang);
  const itemsText = sale.items.map((i) => `• ${i.productName} x ${i.quantity} = ${formatCurrency(i.subtotal, business.currency, lang)}`).join('\n');

  let text = `*${business.name}*\n`;
  text += `🧾 *Invoice:* ${sale.invoiceNumber}\n`;
  text += `📅 *Date:* ${formatDate(sale.createdAt, lang)}\n`;
  text += `👤 *Customer:* ${sale.customerName}\n`;
  text += `-------------------------\n`;
  text += `${itemsText}\n`;
  text += `-------------------------\n`;
  if (sale.discountAmount > 0) {
    text += `*Discount:* -${formatCurrency(sale.discountAmount, business.currency, lang)}\n`;
  }
  text += `*TOTAL:* ${formattedTotal}\n`;
  text += `*Payment:* ${sale.paymentMethod} (${sale.paymentStatus})\n`;
  if (sale.paymentMethod === 'CREDIT') {
    text += `*Outstanding Due:* ${formattedTotal}\n`;
  }
  text += `\n_Thank you for your business!_ 🙏`;

  const encoded = encodeURIComponent(text);
  const phoneClean = sale.customerPhone ? sale.customerPhone.replace(/[^0-9]/g, '') : '';
  const url = phoneClean ? `https://wa.me/${phoneClean}?text=${encoded}` : `https://wa.me/?text=${encoded}`;

  if (Capacitor.isNativePlatform()) {
    try {
      await Share.share({
        title: `${business.name} - Invoice ${sale.invoiceNumber}`,
        text: text,
        dialogTitle: 'Share Invoice / WhatsApp',
      });
      return;
    } catch {
      // fallback to url
    }
  }

  // Web or fallback
  if (window.open) {
    window.open(url, '_blank');
  } else {
    window.location.href = url;
  }
}
