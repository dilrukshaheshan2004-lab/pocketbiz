# PocketBiz APK build

1. Upload this project to GitHub.
2. Open the repository's **Actions** tab.
3. Select **Build PocketBiz APK**.
4. Press **Run workflow**.
5. When the workflow finishes, open the run and download the **PocketBiz-debug-apk** artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

The workflow builds the existing Capacitor Android project using Java 21 and the Android SDK.
